import Foundation

struct User: Codable {
    var id: String
    var nickname: String
    var avatar: Data?
    var bio: String? // 简介
    var aiUsageCount: Int = 10 // 初始赠送10次免费AI次数
    var loginType: LoginType
    var phoneNumber: String?
    var createdAt: Date
    
    enum LoginType: String, Codable {
        case phone
        case wechat
        case qq
        case guest
    }
}
