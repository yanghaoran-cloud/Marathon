import Foundation
import SwiftUI

struct Medal: Identifiable, Codable {
    var id = UUID()
    var title: String
    var description: String
    var imageData: Data
    var createdAt: Date
    var location: String?
    var distance: String?
    var time: String?
}
