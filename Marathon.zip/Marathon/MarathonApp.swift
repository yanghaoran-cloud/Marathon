//
//  MarathonApp.swift
//  Marathon
//
//  Created by 杨淏然 on 2026/3/19.
//

import SwiftUI

@main
struct MarathonApp: App {
    @State private var isLoggedIn = false
    
    init() {
        // 检查用户是否已经登录
        isLoggedIn = DataService.shared.isLoggedIn()
    }
    
    var body: some Scene {
        WindowGroup {
            if isLoggedIn {
                MainTabView(onLogout: { 
                    isLoggedIn = false
                })
            } else {
                OnboardingView(onLogin: { 
                    isLoggedIn = true
                })
            }
        }
    }
}
