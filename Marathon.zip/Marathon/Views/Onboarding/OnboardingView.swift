import SwiftUI

struct OnboardingView: View {
    @State private var currentPage = 0
    @State private var isCompleted = false
    @State private var showMainTabView = false
    var onLogin: (() -> Void)? = nil
    
    private let pages = [
        OnboardingPage(title: "收藏你的马拉松奖牌", description: "记录每一个难忘的马拉松时刻", imageName: "medal", imageSize: CGSize(width: 150, height: 150)),
        OnboardingPage(title: "用AI记录故事", description: "让AI帮你生成感人的马拉松故事", imageName: "brain", imageSize: CGSize(width: 180, height: 180)),
        OnboardingPage(title: "一键分享至社交平台", description: "分享你的成就，激励更多人", imageName: "square.and.arrow.up", imageSize: CGSize(width: 160, height: 160))
    ]
    
    var body: some View {
        ZStack {
            Color.orange.opacity(0.1)
                .ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentPage) {
                    ForEach(0..<pages.count, id: \.self) {
                        index in
                        OnboardingPageView(page: pages[index])
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                
                HStack {
                    Button("跳过") {
                    isCompleted = true
                    onLogin?()
                }
                    .foregroundColor(.orange)
                    .font(.system(size: 16, weight: .medium))
                    
                    Spacer()
                    
                    Button(currentPage == pages.count - 1 ? "开始使用" : "下一步") {
                        if currentPage == pages.count - 1 {
                            isCompleted = true
                            onLogin?()
                        } else {
                            currentPage += 1
                        }
                    }
                    .foregroundColor(.white)
                    .padding(.horizontal, 24)
                    .padding(.vertical, 12)
                    .background(Color.orange)
                    .cornerRadius(24)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 30)
            }
        }
        .fullScreenCover(isPresented: $isCompleted) {
                LoginView(isPresented: $isCompleted) {
                    // 登录成功，导航到MainTabView
                    showMainTabView = true
                    onLogin?()
                }
            }
        .fullScreenCover(isPresented: $showMainTabView) {
            MainTabView()
        }
    }
}

struct OnboardingPage {
    let title: String
    let description: String
    let imageName: String
    let imageSize: CGSize
}

struct OnboardingPageView: View {
    let page: OnboardingPage
    
    var body: some View {
        VStack(spacing: 30) {
            Image(systemName: page.imageName)
                .resizable()
                .scaledToFit()
                .frame(width: page.imageSize.width, height: page.imageSize.height)
                .foregroundColor(.orange)
            
            Text(page.title)
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.black)
            
            Text(page.description)
                .font(.system(size: 16))
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 40)
        }
        .padding(.top, 100)
    }
}
