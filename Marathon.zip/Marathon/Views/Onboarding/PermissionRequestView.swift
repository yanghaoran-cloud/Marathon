import SwiftUI

struct PermissionRequestView: View {
    @State private var showHome = false
    
    var body: some View {
        ZStack {
            Color.orange.opacity(0.1)
                .ignoresSafeArea()
            
            VStack(spacing: 30) {
                Image(systemName: "camera.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.orange)
                
                Text("需要权限才能使用全部功能")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.black)
                
                Text("无权限将无法使用拍照/换图功能")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
                
                Spacer()
                
                VStack(spacing: 20) {
                    Button(action: { grantPermissions() }) {
                        Text("授予权限")
                            .foregroundColor(.white)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(12)
                    }
                    
                    Button(action: { skipPermissions() }) {
                        Text("稍后再说")
                            .foregroundColor(.orange)
                            .font(.system(size: 16, weight: .medium))
                    }
                }
                .padding(.horizontal, 30)
                
                Spacer()
            }
            .padding(.top, 100)
        }
        .fullScreenCover(isPresented: $showHome) {
            MainTabView()
        }
    }
    
    func grantPermissions() {
        // 模拟权限授予
        print("授予权限")
        showHome = true
    }
    
    func skipPermissions() {
        // 跳过权限申请
        print("跳过权限申请")
        showHome = true
    }
}
