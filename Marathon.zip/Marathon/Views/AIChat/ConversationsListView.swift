import SwiftUI

struct ConversationsListView: View {
    @Binding var showConversationsList: Bool
    var onConversationSelected: (String) -> Void
    
    @State private var conversations = AIService.shared.getConversations()
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(conversations.sorted(by: { $0.createdAt > $1.createdAt }), id: \.id) { conversation in
                        Button(action: {
                            onConversationSelected(conversation.id)
                            showConversationsList.toggle()
                        }) {
                            VStack(alignment: .leading) {
                                Text(conversation.title)
                                    .font(.headline)
                                    .lineLimit(1)
                                Text(conversation.createdAt.formatted(.dateTime.month().day().hour().minute()))
                                    .font(.caption)
                                    .foregroundColor(.gray)
                            }
                        }
                        .swipeActions(edge: .trailing, allowsFullSwipe: true) {
                            Button(role: .destructive) {
                                AIService.shared.deleteConversation(conversationId: conversation.id)
                                conversations = AIService.shared.getConversations()
                            } label: {
                                Label("删除", systemImage: "trash")
                            }
                        }
                    }
                }
                
                Button(action: {
                    // 创建新对话
                    let newConversationId = AIService.shared.createNewConversation()
                    conversations = AIService.shared.getConversations()
                    onConversationSelected(newConversationId)
                    showConversationsList.toggle()
                }) {
                    HStack {
                        Image(systemName: "plus.circle")
                        Text("新建对话")
                    }
                    .foregroundColor(.orange)
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.orange, lineWidth: 1)
                    )
                    .padding()
                }
            }
            .navigationBarTitle("对话列表", displayMode: .inline)
            .navigationBarItems(trailing: Button(action: {
                showConversationsList.toggle()
            }) {
                Text("完成")
                    .foregroundColor(.orange)
            })
        }
    }
}
