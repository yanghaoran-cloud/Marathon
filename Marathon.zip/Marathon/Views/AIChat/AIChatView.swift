import SwiftUI
import Foundation

struct AIChatView: View {
    @State private var messages: [ChatMessage] = []
    @State private var inputText: String = ""
    @State private var isLoading: Bool = false
    @State private var showConversationsList: Bool = false
    @State private var showFilePicker: Bool = false
    @State private var showImagePicker: Bool = false
    @State private var attachments: [URL] = []
    
    var body: some View {
        NavigationView {
            VStack {
                // 聊天消息列表
                ScrollView {
                    VStack(spacing: 16) {
                        ForEach(messages) { message in
                            ChatBubble(message: message)
                        }
                    }
                    .padding()
                }
                
                // 加载状态显示
                if isLoading {
                    HStack {
                        Spacer()
                        HStack(spacing: 12) {
                            Text("正在思考中")
                                .font(.system(size: 16))
                                .foregroundColor(.orange)
                            ProgressView()
                                .progressViewStyle(CircularProgressViewStyle(tint: .orange))
                                .scaleEffect(1.0)
                        }
                        Spacer()
                    }
                    .padding(.vertical, 12)
                    .padding(.horizontal, 20)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(12)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 8)
                }
                
                // 输入区域
                VStack {
                    // 附件预览
                    if !attachments.isEmpty {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(attachments, id: \.self) {
                                    attachment in
                                    VStack {
                                        Image(systemName: getFileIcon(for: attachment))
                                            .foregroundColor(.orange)
                                            .font(.system(size: 20))
                                            .frame(width: 50, height: 50)
                                        Text(attachment.lastPathComponent)
                                            .font(.caption2)
                                            .lineLimit(1)
                                            .frame(width: 50)
                                    }
                                    .background(Color.orange.opacity(0.1))
                                    .cornerRadius(8)
                                    .overlay(
                                        Button(action: {
                                            if let index = attachments.firstIndex(of: attachment) {
                                                attachments.remove(at: index)
                                            }
                                        }) {
                                            Image(systemName: "xmark.circle.fill")
                                                .foregroundColor(.red)
                                                .font(.caption2)
                                        }
                                        .offset(x: -8, y: -8)
                                        .alignmentGuide(.top) { _ in 0 }
                                    )
                                }
                            }
                            .padding(.horizontal)
                            .padding(.bottom, 8)
                        }
                    }
                    
                    HStack {
                        // 附件按钮
                        Button(action: {
                            // 显示附件选择菜单
                            let alert = UIAlertController(title: "选择附件", message: "请选择要添加的附件类型", preferredStyle: .actionSheet)
                            alert.addAction(UIAlertAction(title: "从相册选择", style: .default) {
                                _ in
                                showImagePicker.toggle()
                            })
                            alert.addAction(UIAlertAction(title: "选择文件", style: .default) {
                                _ in
                                showFilePicker.toggle()
                            })
                            alert.addAction(UIAlertAction(title: "取消", style: .cancel))
                            UIApplication.shared.windows.first?.rootViewController?.present(alert, animated: true)
                        }) {
                            Image(systemName: "paperclip")
                                .foregroundColor(.orange)
                                .padding(12)
                        }
                        
                        TextField("输入你的问题", text: $inputText)
                            .padding(12)
                            .background(Color.orange.opacity(0.1))
                            .cornerRadius(12)
                            .lineLimit(3)
                            .multilineTextAlignment(.leading)
                            .font(.system(size: 16))
                        
                        // 语音输入按钮
                        Button(action: { 
                            // 开始录音
                            print("开始录音")
                            // 这里需要实现实际的录音功能
                        }) {
                            Image(systemName: "mic.fill")
                                .foregroundColor(.orange)
                                .padding(12)
                                .background(Color.orange.opacity(0.1))
                                .cornerRadius(12)
                        }
                        
                        Button(action: sendMessage) {
                            Image(systemName: "paperplane.fill")
                                .foregroundColor(.orange)
                                .padding(12)
                        }
                        .disabled((inputText.isEmpty && attachments.isEmpty) || isLoading)
                    }
                    .padding()
                }
            }
            .navigationBarTitle("AI跑步助手", displayMode: .inline)
            .navigationBarItems(leading: Button(action: {
                showConversationsList.toggle()
            }) {
                Image(systemName: "list.bullet")
                    .foregroundColor(.orange)
            })
        }
        .onAppear {
            loadCurrentConversationMessages()
        }
        .sheet(isPresented: $showConversationsList) {
            ConversationsListView(showConversationsList: $showConversationsList, onConversationSelected: loadConversationMessages)
        }
        .sheet(isPresented: $showFilePicker) {
            DocumentPicker(attachments: $attachments)
        }
        .sheet(isPresented: $showImagePicker) {
            ChatImagePicker(attachments: $attachments)
        }
    }
    
    func sendMessage() {
        print("sendMessage called with: \(inputText), attachments: \(attachments)")
        guard !inputText.isEmpty || !attachments.isEmpty else { return }
        
        // 构建消息内容，包含文本和附件信息
        var messageContent = inputText
        if !attachments.isEmpty {
            messageContent += "\n\n附件: "
            for attachment in attachments {
                messageContent += "\n- \(attachment.lastPathComponent)"
            }
        }
        
        // 添加用户消息
        let userMessage = ChatMessage(id: UUID().uuidString, content: messageContent, isUser: true)
        messages.append(userMessage)
        print("User message added")
        
        // 清空输入框和附件
        let question = inputText
        inputText = ""
        let messageAttachments = attachments
        attachments = []
        
        // 创建一个临时的AI消息ID，用于后续更新
        let aiMessageId = UUID().uuidString
        // 添加一个空的AI消息占位符
        let aiMessage = ChatMessage(id: aiMessageId, content: "", isUser: false)
        messages.append(aiMessage)
        print("AI message placeholder added")
        
        // 显示加载状态（确保在主线程上）
        DispatchQueue.main.async {
            self.isLoading = true
            print("Loading state set to true")
        }
        
        // 调用AIService的sendMessage方法获取API响应
        Task {
            do {
                // 调用带回调的sendMessage方法，处理完整响应
                let finalReply = try await AIService.shared.sendMessage(question, attachments: messageAttachments) { chunk in
                    // 这个回调只会被调用一次，包含完整的响应
                    // 在主线程上更新UI
                    DispatchQueue.main.async {
                        if let index = self.messages.firstIndex(where: { $0.id == aiMessageId }) {
                            var updatedMessages = self.messages
                            updatedMessages[index] = ChatMessage(id: aiMessageId, content: chunk, isUser: false)
                            self.messages = updatedMessages
                            print("Updated AI message with full response: \(chunk)")
                        }
                    }
                }
                print("API response completed: \(finalReply)")
                
                // 隐藏加载状态
                DispatchQueue.main.async {
                    self.isLoading = false
                    print("Loading state set to false")
                }
            } catch {
                print("API error: \(error)")
                // 显示错误信息
                DispatchQueue.main.async {
                    // 找到对应的AI消息并更新为错误信息
                    if let index = self.messages.firstIndex(where: { $0.id == aiMessageId }) {
                        var updatedMessages = self.messages
                        let errorMessage = "API调用失败，请稍后重试。错误：\(error.localizedDescription)"
                        updatedMessages[index] = ChatMessage(id: aiMessageId, content: errorMessage, isUser: false)
                        self.messages = updatedMessages
                    }
                    self.isLoading = false
                    print("Loading state set to false")
                }
            }
        }
    }
    
    // 加载当前对话的消息
    func loadCurrentConversationMessages() {
        let currentConversation = AIService.shared.getCurrentConversation()
        loadConversationMessages(conversationId: currentConversation.id)
    }
    
    // 获取文件图标
    func getFileIcon(for url: URL) -> String {
        let pathExtension = url.pathExtension.lowercased()
        switch pathExtension {
        case "pdf":
            return "doc.text.fill"
        case "doc", "docx":
            return "doc.fill"
        case "xls", "xlsx":
            return "table"
        case "jpg", "jpeg", "png", "gif":
            return "photo"
        case "mp3", "wav", "m4a":
            return "waveform"
        case "mp4", "mov":
            return "film"
        default:
            return "paperclip"
        }
    }
    

    
    // 加载指定对话的消息
    func loadConversationMessages(conversationId: String) {
        // 切换到指定对话
        AIService.shared.switchConversation(to: conversationId)
        
        // 清空当前消息
        messages.removeAll()
        
        // 加载对话消息
        let currentConversation = AIService.shared.getCurrentConversation()
        let conversationMessages = currentConversation.messages
        for (index, message) in conversationMessages.enumerated() {
            if let content = message["content"] as? String, let role = message["role"] as? String {
                let isUser = role == "user"
                messages.append(ChatMessage(id: "msg_\(index)", content: content, isUser: isUser))
            }
        }
        
        // 如果对话为空，添加欢迎消息
        if messages.isEmpty {
            messages.append(ChatMessage(id: UUID().uuidString, content: "你好！我是你的AI跑步助手，有什么关于跑步的问题可以问我哦！", isUser: false))
        }
    }
    

}

struct ChatMessage: Identifiable {
    let id: String
    let content: String
    let isUser: Bool
    let timestamp: Date = Date()
}

struct ChatBubble: View {
    let message: ChatMessage
    
    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            if message.isUser {
                Spacer()
                Text(message.content)
                    .padding(12)
                    .background(Color.orange)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .frame(maxWidth: 250, alignment: .trailing)
                    .font(.system(size: 16))
            } else {
                Image(systemName: "brain.fill")
                    .foregroundColor(.orange)
                    .padding(4)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(12)
                Text(message.content)
                    .padding(12)
                    .background(Color.gray.opacity(0.1))
                    .foregroundColor(.black)
                    .cornerRadius(12)
                    .frame(maxWidth: 250, alignment: .leading)
                    .font(.system(size: 16))
                Spacer()
            }
        }
    }
}
