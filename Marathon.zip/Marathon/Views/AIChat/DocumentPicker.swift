import SwiftUI
import UIKit

struct DocumentPicker: UIViewControllerRepresentable {
    @Binding var attachments: [URL]
    
    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        // 使用更广泛的UTI字符串创建文档选择器，确保能访问所有类型的文件
        let documentTypes = [
            "public.pdf",
            "com.microsoft.word.doc",
            "org.openxmlformats.wordprocessingml.document", // docx
            "com.microsoft.excel.xls",
            "org.openxmlformats.spreadsheetml.sheet", // xlsx
            "public.plain-text",
            "public.image",
            "public.text",
            "public.data"
        ]
        let picker = UIDocumentPickerViewController(documentTypes: documentTypes, in: .import)
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = true
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UIDocumentPickerDelegate {
        let parent: DocumentPicker
        
        init(_ parent: DocumentPicker) {
            self.parent = parent
        }
        
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            for url in urls {
                parent.attachments.append(url)
            }
        }
        
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            // 取消选择
        }
    }
}
