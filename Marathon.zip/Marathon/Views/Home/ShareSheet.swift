import SwiftUI

struct ShareSheet: View {
    let medal: Medal
    let onShare: (SharePlatform) -> Void
    let onCancel: () -> Void
    
    var body: some View {
        VStack(spacing: 20) {
            // 标题
            Text("分享到")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
            
            // 分享平台图标
            HStack {
                Spacer()
                shareButton(imageName: "house", title: "小红书", platform: .xiaohongshu)
                Spacer()
                shareButton(imageName: "message", title: "微信", platform: .wechat)
                Spacer()
                shareButton(imageName: "person.2", title: "朋友圈", platform: .moments)
                Spacer()
                shareButton(imageName: "text.bubble", title: "QQ", platform: .qq)
                Spacer()
                shareButton(imageName: "play.rectangle", title: "抖音", platform: .douyin)
                Spacer()
            }
            
            // 取消按钮
            Button("取消") {
                onCancel()
            }
            .foregroundColor(.orange)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(Color.orange.opacity(0.1))
            .cornerRadius(12)
            .padding(.horizontal, 20)
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(20, corners: [.topLeft, .topRight])
    }
    
    private func shareButton(imageName: String, title: String, platform: SharePlatform) -> some View {
        VStack(spacing: 8) {
            Button(action: {
                onShare(platform)
            }) {
                Image(systemName: imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)
                    .foregroundColor(.orange)
                    .padding(12)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(20)
            }
            Text(title)
                .font(.system(size: 12))
                .foregroundColor(.black)
        }
    }
}

// 扩展 View 以支持圆角
extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}
