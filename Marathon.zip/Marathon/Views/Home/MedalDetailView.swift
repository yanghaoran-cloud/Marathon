import SwiftUI

struct MedalDetailView: View {
    @Environment(\.dismiss) private var dismiss
    let medal: Medal
    let onDelete: (() -> Void)?
    @State private var showEdit = false
    @State private var showDeleteConfirm = false
    @State private var showShareSheet = false
    @State private var showXiaohongshuEdit = false
    @State private var currentMedal: Medal
    
    init(medal: Medal, onDelete: (() -> Void)? = nil) {
        self.medal = medal
        self.onDelete = onDelete
        _currentMedal = State(initialValue: medal)
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 奖牌照片
                    Image(uiImage: UIImage(data: currentMedal.imageData) ?? UIImage(systemName: "medal")!)
                        .resizable()
                        .aspectRatio(1, contentMode: .fit)
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    
                    // 标题
                    Text(currentMedal.title)
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.black)
                    
                    // 描述
                    Text(currentMedal.description)
                        .font(.system(size: 16))
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 20)
                    
                    // 额外信息
                    if let location = currentMedal.location {
                        HStack {
                            Image(systemName: "location")
                                .foregroundColor(.orange)
                            Text(location)
                                .font(.system(size: 14))
                                .foregroundColor(.black)
                        }
                    }
                    
                    if let distance = currentMedal.distance {
                        HStack {
                            Image(systemName: "figure.run")
                                .foregroundColor(.orange)
                            Text(distance)
                                .font(.system(size: 14))
                                .foregroundColor(.black)
                        }
                    }
                    
                    if let time = currentMedal.time {
                        HStack {
                            Image(systemName: "clock")
                                .foregroundColor(.orange)
                            Text(time)
                                .font(.system(size: 14))
                                .foregroundColor(.black)
                        }
                    }
                }
                .padding(.top, 20)
            }
            .onAppear {
                // 重新加载奖牌数据
                let medals = DataService.shared.loadMedals()
                if let updatedMedal = medals.first(where: { $0.id == medal.id }) {
                    currentMedal = updatedMedal
                }
            }
            .navigationBarTitle("奖牌详情", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    // 返回上一页
                    print("返回")
                    dismiss()
                },
                trailing: HStack {
                    Button(action: { shareMedal() }) {
                        Image(systemName: "square.and.arrow.up")
                            .foregroundColor(.orange)
                    }
                    .padding(.trailing, 10)
                    
                    Button(action: { showEdit = true }) {
                        Image(systemName: "pencil")
                            .foregroundColor(.orange)
                    }
                    .padding(.trailing, 10)
                    
                    Button(action: { showDeleteConfirm = true }) {
                        Image(systemName: "trash")
                            .foregroundColor(.orange)
                    }
                }
            )
        }
        .fullScreenCover(isPresented: $showEdit, onDismiss: { 
            // 从编辑页面返回时重新加载数据
            let medals = DataService.shared.loadMedals()
            if let updatedMedal = medals.first(where: { $0.id == medal.id }) {
                currentMedal = updatedMedal
            }
        }) {
            EditMedalView(medal: medal)
        }
        .alert(isPresented: $showDeleteConfirm) {
            Alert(
                title: Text("确认删除"),
                message: Text("确定要删除这个奖牌吗？此操作不可恢复。"),
                primaryButton: .destructive(Text("删除")) { 
                    deleteMedal()
                },
                secondaryButton: .cancel()
            )
        }
        .sheet(isPresented: $showShareSheet) {
            ShareSheet(medal: medal, onShare: { platform in
                switch platform {
                case .xiaohongshu:
                    showXiaohongshuEdit = true
                case .wechat:
                    ShareService.shared.shareToWechat(medal: medal)
                case .moments:
                    // 微信朋友圈分享
                    ShareService.shared.shareToWechat(medal: medal)
                case .qq:
                    ShareService.shared.shareToQQ(medal: medal)
                case .douyin:
                    ShareService.shared.shareToDouyin(medal: medal)
                }
                showShareSheet = false
            }, onCancel: {
                showShareSheet = false
            })
        }
        .fullScreenCover(isPresented: $showXiaohongshuEdit) {
            XiaohongshuEditView(medal: medal, onCancel: {
                showXiaohongshuEdit = false
            })
        }
    }
    
    func shareMedal() {
        // 显示分享面板
        showShareSheet = true
    }
    
    func deleteMedal() {
        // 删除奖牌
        var medals = DataService.shared.loadMedals()
        medals.removeAll { $0.id == medal.id }
        DataService.shared.saveMedals(medals)
        
        // 通知调用方删除完成，需要刷新数据
        onDelete?()
        
        print("删除奖牌成功")
        dismiss()
    }
}
