import SwiftUI

struct EditMedalView: View {
    @Environment(\.dismiss) private var dismiss
    let medal: Medal
    @State private var title: String
    @State private var description: String
    @State private var imageData: Data
    @State private var showImagePicker = false
    @State private var isAIProcessing = false
    
    init(medal: Medal) {
        self.medal = medal
        _title = State(initialValue: medal.title)
        _description = State(initialValue: medal.description)
        _imageData = State(initialValue: medal.imageData)
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 奖牌照片
                    ZStack {
                        Image(uiImage: UIImage(data: imageData) ?? UIImage(systemName: "medal")!)
                            .resizable()
                            .aspectRatio(1, contentMode: .fit)
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                        
                        VStack {
                            Spacer()
                            HStack {
                                Spacer()
                                Button(action: { showImagePicker = true }) {
                                    Image(systemName: "camera")
                                        .foregroundColor(.white)
                                        .padding(10)
                                        .background(Color.orange)
                                        .cornerRadius(20)
                                }
                                .padding(20)
                            }
                        }
                    }
                    
                    // AI画面修复
                    Button(action: { enhanceImage() }) {
                        HStack {
                            Image(systemName: "wand.and.stars")
                                .foregroundColor(.orange)
                            Text("AI画面修复")
                                .foregroundColor(.orange)
                                .font(.system(size: 16, weight: .medium))
                        }
                        .padding(.vertical, 12)
                        .frame(maxWidth: .infinity)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    }
                    
                    // 标题编辑
                    TextField("奖牌标题", text: $title)
                        .padding(16)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    
                    // 描述编辑
                    TextEditor(text: $description)
                        .padding(16)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                        .frame(height: 150)
                    
                    // AI文案优化
                    Button(action: { optimizeCopywriting() }) {
                        HStack {
                            Image(systemName: "brain")
                                .foregroundColor(.orange)
                            Text("AI文案优化")
                                .foregroundColor(.orange)
                                .font(.system(size: 16, weight: .medium))
                        }
                        .padding(.vertical, 12)
                        .frame(maxWidth: .infinity)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    }
                    
                    // 保存按钮
                    Button(action: { saveMedal() }) {
                        Text("保存")
                            .foregroundColor(.white)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                    }
                }
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("编辑奖牌", displayMode: .inline)
            .navigationBarItems(
                leading: Button("取消") {
                    // 取消编辑，重置表单到原始状态
                    title = medal.title
                    description = medal.description
                    imageData = medal.imageData
                    print("取消编辑")
                    dismiss()
                }
            )
        }
        .overlay {
            if isAIProcessing {
                ZStack {
                    Color.black.opacity(0.5)
                    VStack {
                        ProgressView()
                        Text("AI处理中...")
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                }
                .ignoresSafeArea()
            }
        }
    }
    
    func enhanceImage() {
        // 检查AI次数
        if !DataService.shared.decreaseAIUsageCount() {
            print("AI次数不足")
            return
        }
        
        isAIProcessing = true
        
        // 模拟AI画面修复
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            isAIProcessing = false
            print("AI画面修复完成")
        }
    }
    
    func optimizeCopywriting() {
        // 检查AI次数
        if !DataService.shared.decreaseAIUsageCount() {
            print("AI次数不足")
            return
        }
        
        isAIProcessing = true
        
        // 模拟AI文案优化
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            description = "AI优化后的文案：\n" + description
            isAIProcessing = false
            print("AI文案优化完成")
        }
    }
    
    func saveMedal() {
        // 保存奖牌信息
        var updatedMedal = medal
        updatedMedal.title = title
        updatedMedal.description = description
        updatedMedal.imageData = imageData
        
        var medals = DataService.shared.loadMedals()
        if let index = medals.firstIndex(where: { $0.id == updatedMedal.id }) {
            medals[index] = updatedMedal
            DataService.shared.saveMedals(medals)
        }
        
        print("保存成功")
        dismiss()
    }
}
