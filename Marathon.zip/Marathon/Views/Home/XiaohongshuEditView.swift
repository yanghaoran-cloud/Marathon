import SwiftUI
import UIKit

struct XiaohongshuEditView: View {
    @Environment(\.dismiss) private var dismiss
    let medal: Medal
    let onCancel: () -> Void
    @State private var images: [Data] = []
    @State private var title: String = ""
    @State private var content: String = ""
    @State private var showImagePicker = false
    @State private var imagePickerSourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var isAIProcessing = false
    
    init(medal: Medal, onCancel: @escaping () -> Void) {
        self.medal = medal
        self.onCancel = onCancel
        _title = State(initialValue: medal.title)
        _content = State(initialValue: medal.description)
        _images = State(initialValue: [medal.imageData])
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 照片选择区域
                    HStack(spacing: 10) {
                        ForEach(0..<min(9, images.count + 1), id: \.self) { index in
                            if index < images.count {
                                // 已选择的照片
                                Image(uiImage: UIImage(data: images[index]) ?? UIImage(systemName: "photo")!)
                                    .resizable()
                                    .aspectRatio(1, contentMode: .fill)
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(8)
                            } else {
                                // 添加照片按钮
                                Button(action: { showImagePicker = true }) {
                                    VStack(spacing: 10) {
                                        Image(systemName: "camera.fill")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 30, height: 30)
                                            .foregroundColor(.orange)
                                        Text("添加照片")
                                            .font(.system(size: 12))
                                            .foregroundColor(.gray)
                                    }
                                    .frame(width: 100, height: 100)
                                    .background(Color.orange.opacity(0.1))
                                    .cornerRadius(8)
                                }
                            }
                        }
                    }
                    .padding(.horizontal, 20)
                    
                    // 标题输入
                    TextField("主标题", text: $title)
                        .padding(16)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .frame(width: 340)
                    
                    // 内容输入
                    TextEditor(text: $content)
                        .padding(16)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .frame(width: 340, height: 200)
                    
                    // AI优化按钮
                    Button(action: { optimizeContent() }) {
                        HStack {
                            Image(systemName: "brain")
                                .foregroundColor(.orange)
                            Text("AI内容优化")
                                .foregroundColor(.orange)
                                .font(.system(size: 16, weight: .medium))
                        }
                        .padding(.vertical, 12)
                        .frame(maxWidth: .infinity)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    }
                    

                }
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("小红书编辑", displayMode: .inline)
            .navigationBarItems(
                leading: Button("取消") {
                    onCancel()
                },
                trailing: Button("发布") {
                    publish()
                }
            )
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(sourceType: $imagePickerSourceType, selectedImage: { imageData in
                if let imageData = imageData {
                    images.append(imageData)
                }
            })
        }
        .overlay {
            if isAIProcessing {
                ZStack {
                    Color.black.opacity(0.5)
                    VStack {
                        ProgressView()
                        Text("AI处理中...")
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                }
                .ignoresSafeArea()
            }
        }
    }
    
    func optimizeContent() {
        // 检查AI次数
        if !DataService.shared.decreaseAIUsageCount() {
            print("AI次数不足")
            return
        }
        
        isAIProcessing = true
        
        // 模拟AI内容优化
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            content = "AI优化后的内容：\n" + content
            isAIProcessing = false
            print("AI内容优化完成")
        }
    }
    
    func publish() {
        print("发布到小红书")
        print("标题: \(title)")
        print("内容: \(content)")
        print("图片数量: \(images.count)")
        
        // 模拟发布成功
        onCancel()
    }
}
