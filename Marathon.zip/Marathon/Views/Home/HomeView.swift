import SwiftUI

struct HomeView: View {
    @State private var medals: [Medal] = []
    @State private var filteredMedals: [Medal] = []
    @State private var searchText: String = ""
    @State private var selectedMedal: Medal? = nil
    @State private var needRefresh: Bool = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 5) {
                    // 大标题 - Apple Design风格，苹方加粗，左上角，紧贴状态栏
                    Text("马拉松奖牌")
                        .font(.system(size: 32, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.top, -90)
                        .padding(.leading, 20)
                    
                    // 顶部Banner - 向上移动40pt
                    BannerView()
                        .padding(.horizontal, 20)
                        .padding(.top, -30)
                    
                    // 搜索栏
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.gray)
                        TextField("搜索奖牌...", text: $searchText, onCommit: {
                            filterMedals()
                        })
                        if !searchText.isEmpty {
                            Button(action: {
                                searchText = ""
                                filterMedals()
                            }) {
                                Image(systemName: "xmark.circle")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding(12)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(12)
                    .padding(.horizontal, 20)
                    .padding(.top, 20)
                    
                    // 奖牌卡片瀑布流
                    MedalGrid(medals: $filteredMedals, onMedalTap: { medal in
                        print("设置selectedMedal: \(medal.title)")
                        selectedMedal = medal
                    })
                }
                .padding(.bottom, 40)
            }
            .navigationBarHidden(true) // 隐藏导航栏，使用自定义标题
        }
        .sheet(item: $selectedMedal) {
            medal in
            MedalDetailView(medal: medal, onDelete: { 
                print("收到删除通知，刷新数据")
                loadMedals()
            })
        }
        .onAppear {
            loadMedals()
        }
    }
    
    func loadMedals() {
        medals = DataService.shared.loadMedals()
        filterMedals()
    }
    
    func filterMedals() {
        if searchText.isEmpty {
            filteredMedals = medals
        } else {
            filteredMedals = medals.filter { medal in
                medal.title.lowercased().contains(searchText.lowercased()) || 
                (medal.description.lowercased().contains(searchText.lowercased()))
            }
        }
    }
}

struct BannerView: View {
    @State private var currentIndex = 0
    
    let banners = [
        (title: "马拉松备忘录", subtitle: "收集你挥汗如雨的峥嵘岁月", color: Color.orange.opacity(0.1)),
        (title: "AI内容优化", subtitle: "让你的分享更有吸引力", color: Color.blue.opacity(0.1)),
        (title: "多平台分享", subtitle: "一键分享到小红书、微信等平台", color: Color.green.opacity(0.1))
    ]
    
    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $currentIndex) {
                ForEach(0..<banners.count, id: \.self) {
                    index in
                    VStack(spacing: 8) {
                        Text(banners[index].title)
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.orange)
                        Text(banners[index].subtitle)
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    .frame(width: 340, height: 100)
                    .background(banners[index].color)
                    .cornerRadius(12)
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
            .frame(width: 340, height: 100)
            
            HStack(spacing: 6) {
                ForEach(0..<banners.count, id: \.self) {
                    index in
                    Circle()
                        .frame(width: 8, height: 8)
                        .foregroundColor(index == currentIndex ? .orange : .gray.opacity(0.5))
                }
            }
            .padding(.bottom, 8)
        }
        .shadow(radius: 2)
        .onTapGesture {
            // 点击跳转添加奖牌页
            print("跳转到添加奖牌页")
        }
        .onAppear {
            startAutoScroll()
        }
    }
    
    func startAutoScroll() {
        Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { _ in
            withAnimation {
                currentIndex = (currentIndex + 1) % banners.count
            }
        }
    }
}

struct MedalGrid: View {
    @Binding var medals: [Medal]
    var onMedalTap: (Medal) -> Void
    
    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 16) {
            ForEach(medals) { medal in
                MedalCard(medal: medal) { selectedMedal in
                    onMedalTap(selectedMedal)
                }
            }
        }
        .padding(.top, 20)
        .padding(.horizontal, 20)
    }
}

struct MedalCard: View {
    let medal: Medal
    var onTap: (Medal) -> Void
    
    var body: some View {
        VStack(spacing: 8) {
            // 1:1 奖牌照片
            Image(uiImage: UIImage(data: medal.imageData) ?? UIImage(systemName: "medal")!)
                .resizable()
                .aspectRatio(1, contentMode: .fill)
                .frame(height: 150)
                .cornerRadius(8)
            
            // 标题
            Text(medal.title)
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.black)
                .lineLimit(2)
                .padding(.horizontal, 8)
                .padding(.bottom, 8)
        }
        .frame(height: 200) // 3:4比例 (150:200 = 3:4)
        .background(Color.white)
        .cornerRadius(12)
        .shadow(radius: 2)
        .onTapGesture {
            print("点击了奖牌: \(medal.title)")
            onTap(medal)
        }
    }
}
