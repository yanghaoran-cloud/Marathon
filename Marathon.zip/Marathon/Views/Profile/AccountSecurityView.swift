import SwiftUI

struct AccountSecurityView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var showChangePassword = false
    @State private var showBindPhone = false
    @State private var showBindWechat = false
    @State private var showBindQQ = false
    @State private var showTwoFactorAuth = false
    @State private var isPhoneBound = true
    @State private var isWechatBound = true
    @State private var isQQBound = false
    @State private var isTwoFactorEnabled = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 账号安全状态
                    Section {
                        HStack {
                            Text("账号安全状态")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Text("安全")
                                .font(.system(size: 15))
                                .foregroundColor(.green)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 密码管理
                    Section {
                        Button(action: { showChangePassword = true }) {
                            HStack {
                                Text("修改密码")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 账号绑定
                    Section {
                        Text("账号绑定")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Button(action: { showBindPhone = true }) {
                            HStack {
                                Text("手机号")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Text(isPhoneBound ? "已绑定" : "未绑定")
                                    .font(.system(size: 15))
                                    .foregroundColor(isPhoneBound ? .green : .gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                        
                        Button(action: { showBindWechat = true }) {
                            HStack {
                                Text("微信")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Text(isWechatBound ? "已绑定" : "未绑定")
                                    .font(.system(size: 15))
                                    .foregroundColor(isWechatBound ? .green : .gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                        
                        Button(action: { showBindQQ = true }) {
                            HStack {
                                Text("QQ")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Text(isQQBound ? "已绑定" : "未绑定")
                                    .font(.system(size: 15))
                                    .foregroundColor(isQQBound ? .green : .gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 两步验证
                    Section {
                        Button(action: { showTwoFactorAuth = true }) {
                            HStack {
                                Text("两步验证")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Text(isTwoFactorEnabled ? "已开启" : "未开启")
                                    .font(.system(size: 15))
                                    .foregroundColor(isTwoFactorEnabled ? .green : .gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("账号安全", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    dismiss()
                }
            )
        }
    }
}
