import SwiftUI

struct CacheCleanView: View {
    @State private var cacheSize: String = "0 MB"
    @State private var isCleaning = false
    @State private var showConfirmDialog = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 缓存大小
                    Section {
                        HStack {
                            Text("缓存大小")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Text(cacheSize)
                                .font(.system(size: 15))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 清理缓存
                    Button(action: { showConfirmDialog = true }) {
                        Text("清理缓存")
                            .font(.system(size: 16))
                            .foregroundColor(.orange)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white)
                            .cornerRadius(12)
                    }
                    
                    // 缓存说明
                    Section {
                        Text("缓存包含以下内容：")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("• 图片缓存")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            Text("• 临时文件")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            Text("• 应用数据")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("缓存清理", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    // 返回上一页
                }
            )
        }
        .alert(isPresented: $showConfirmDialog) {
            Alert(
                title: Text("确认清理"),
                message: Text("清理缓存将删除所有临时数据，确定要继续吗？"),
                primaryButton: .destructive(Text("确定"), action: { cleanCache() }),
                secondaryButton: .cancel()
            )
        }
        .overlay {
            if isCleaning {
                ZStack {
                    Color.black.opacity(0.5)
                    VStack {
                        ProgressView()
                        Text("清理中...")
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                }
                .ignoresSafeArea()
            }
        }
        .onAppear {
            calculateCacheSize()
        }
    }
    
    func calculateCacheSize() {
        // 模拟计算缓存大小
        cacheSize = "12.5 MB"
    }
    
    func cleanCache() {
        isCleaning = true
        
        // 模拟清理过程
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            isCleaning = false
            cacheSize = "0 MB"
            print("缓存清理完成")
        }
    }
}
