import SwiftUI

struct RechargeView: View {
    @Binding var isPresented: Bool
    @State private var selectedPackage = 0
    @State private var selectedPaymentMethod = 0
    @State private var isPaymentSuccess = false
    
    // 充值套餐选项
    let packages = [
        PackageOption(price: "9.9元", count: 30),
        PackageOption(price: "19.9元", count: 70),
        PackageOption(price: "24.9元", count: 100)
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 充值选项
                    Text("充值AI次数")
                        .font(.system(size: 20, weight: .bold))
                        .foregroundColor(.black)
                    
                    // 充值套餐选择
                    VStack(spacing: 10) {
                        Text("选择充值套餐")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        VStack(spacing: 10) {
                            ForEach(0..<packages.count, id: \.self) {
                                index in
                                PackageButton(
                                    package: packages[index],
                                    isSelected: selectedPackage == index,
                                    onTap: { selectedPackage = index }
                                )
                            }
                        }
                    }
                    .padding(20)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(12)
                    .padding(.horizontal, 20)
                    
                    // 支付方式
                    VStack(spacing: 10) {
                        Text("选择支付方式")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        HStack(spacing: 10) {
                            PaymentMethodButton(title: "微信支付", icon: "message", isSelected: selectedPaymentMethod == 0, onTap: { selectedPaymentMethod = 0 })
                            PaymentMethodButton(title: "支付宝", icon: "creditcard", isSelected: selectedPaymentMethod == 1, onTap: { selectedPaymentMethod = 1 })
                        }
                    }
                    .padding(.horizontal, 20)
                    
                    // 充值按钮
                    Button(action: { processPayment() }) {
                        Text("立即充值")
                            .foregroundColor(.white)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                    }
                }
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("充值", displayMode: .inline)
            .navigationBarItems(
                leading: Button("取消") {
                    // 取消充值，返回上级页面
                    isPresented = false
                    print("取消充值")
                }
            )
        }
        .fullScreenCover(isPresented: $isPaymentSuccess) {
            // 支付成功提示
            VStack {
                Image(systemName: "checkmark.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.green)
                Text("充值成功！")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.black)
                Text("已到账\(packages[selectedPackage].count)次AI次数")
                    .font(.system(size: 16))
                    .foregroundColor(.gray)
                Button("确定") {
                    isPaymentSuccess = false
                    isPresented = false // 充值成功后也返回上级页面
                }
                .padding(.top, 20)
                .foregroundColor(.orange)
            }
            .padding()
        }
    }
    
    func processPayment() {
        // 模拟支付流程
        print("开始支付...")
        
        // 模拟支付成功
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            // 增加AI次数
            DataService.shared.addAIUsageCount(packages[selectedPackage].count)
            isPaymentSuccess = true
            print("支付成功")
        }
    }
}

struct PackageOption {
    let price: String
    let count: Int
}

struct PackageButton: View {
    let package: PackageOption
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack {
                Text(package.price)
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(isSelected ? .orange : .black)
                Spacer()
                Text("= \(package.count)次AI次数")
                    .font(.system(size: 16))
                    .foregroundColor(isSelected ? .orange : .black)
                if isSelected {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.orange)
                }
            }
            .padding(16)
            .background(isSelected ? Color.orange.opacity(0.1) : Color.gray.opacity(0.1))
            .cornerRadius(12)
        }
    }
}

struct PaymentMethodButton: View {
    let title: String
    let icon: String
    let isSelected: Bool
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 10) {
                Image(systemName: icon)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 40, height: 40)
                    .foregroundColor(isSelected ? .orange : .gray)
                Text(title)
                    .font(.system(size: 14))
                    .foregroundColor(isSelected ? .orange : .gray)
            }
            .padding(20)
            .background(isSelected ? Color.orange.opacity(0.1) : Color.gray.opacity(0.1))
            .cornerRadius(12)
            .frame(maxWidth: .infinity)
        }
    }
}
