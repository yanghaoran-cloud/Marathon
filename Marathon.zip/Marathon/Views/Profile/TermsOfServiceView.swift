import SwiftUI

struct TermsOfServiceView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("服务条款")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.top, 20)
                    
                    Text("生效日期：2026年3月1日")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                    
                    Section {
                        Text("1. 服务内容")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("Marathon应用（以下简称\"本应用\"）提供马拉松奖牌收藏与故事记录服务，包括但不限于：")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 马拉松奖牌的收藏与管理")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- AI辅助生成社交平台文案")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 多平台分享功能")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("2. 用户注册与账号管理")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("2.1 用户注册")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("您可以通过手机号、微信或QQ账号注册并登录本应用。注册时，您需要提供真实、准确、完整的个人信息。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("2.2 账号管理")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("您应妥善保管您的账号和密码，对使用您账号进行的所有操作负责。如发现账号被他人非法使用，应立即通知我们。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("3. 用户权利与义务")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("3.1 用户权利")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("- 使用本应用提供的服务")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 管理个人账号信息")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 对本应用提出建议和意见")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("3.2 用户义务")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("- 遵守法律法规和公序良俗")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 不发布违法、违规或不良信息")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 不侵犯他人的知识产权和合法权益")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 不干扰本应用的正常运行")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("4. AI功能与付费机制")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("4.1 AI功能")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("本应用提供AI画面修复、文案优化和社交平台文案生成等功能。使用AI功能需要消耗AI次数。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("4.2 付费机制")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("新用户注册后可获得10次免费AI次数。当免费次数用完后，您可以通过充值购买AI次数。充值后，AI次数将立即到账。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("5. 知识产权")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("本应用的所有内容，包括但不限于文字、图片、音频、视频、软件、代码、界面设计、logo等，均受知识产权法律法规的保护。未经我们授权，任何个人或组织不得使用、复制、修改、传播或商业利用。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("6. 服务变更、中断或终止")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("我们有权根据业务发展需要，变更、中断或终止部分或全部服务。如因系统维护、升级等原因需要暂时中断服务，我们将提前通知您。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("7. 免责声明")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("本应用仅提供服务平台，不保证服务的完美性、安全性和及时性。对于因使用本应用而产生的任何损失，我们不承担赔偿责任。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("8. 法律适用与争议解决")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("本服务条款的订立、执行、解释及争议的解决均适用中华人民共和国法律。如发生争议，双方应友好协商解决；协商不成的，任何一方均有权向有管辖权的人民法院提起诉讼。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("9. 服务条款更新")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("我们可能会不时更新本服务条款。当我们进行重大变更时，我们会通过应用内通知或电子邮件通知您。继续使用本应用即表示您接受更新后的服务条款。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("10. 联系我们")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("如果您对本服务条款有任何疑问，请通过以下方式联系我们：")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 电子邮件：support@marathonapp.com")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 客服电话：400-123-4567")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("服务条款", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    dismiss()
                }
            )
        }
    }
}
