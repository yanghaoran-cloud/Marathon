import SwiftUI

struct CacheCleanupView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var cacheSize: String = "128MB"
    @State private var isCleaning: Bool = false
    @State private var showSuccessAlert: Bool = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 缓存大小
                    Section {
                        HStack {
                            Text("当前缓存大小")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Text(cacheSize)
                                .font(.system(size: 15))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 清理缓存按钮
                    Button(action: { cleanCache() }) {
                        Text(isCleaning ? "清理中..." : "清理缓存")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(isCleaning ? Color.gray : Color.orange)
                            .cornerRadius(12)
                            .disabled(isCleaning)
                    }
                    
                    // 缓存说明
                    Section {
                        Text("缓存说明")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text("缓存包括应用运行过程中产生的临时文件、图片缓存等。清理缓存可以释放存储空间，但不会影响您的个人数据和设置。")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                            .lineLimit(nil)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("缓存清理", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    dismiss()
                }
            )
            .alert(isPresented: $showSuccessAlert) {
                Alert(title: Text("清理成功"), message: Text("缓存已清理完成"), dismissButton: .default(Text("确定")))
            }
        }
    }
    
    func cleanCache() {
        isCleaning = true
        
        // 模拟清理过程
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            cacheSize = "0MB"
            isCleaning = false
            showSuccessAlert = true
        }
    }
}
