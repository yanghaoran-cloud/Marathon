import SwiftUI

struct NotificationSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var allowPushNotifications = true
    @State private var allowReminders = true
    @State private var allowAchievementNotifications = true
    @State private var allowPromotionalNotifications = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 推送通知
                    Section {
                        HStack {
                            Text("推送通知")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Toggle("", isOn: $allowPushNotifications)
                                .foregroundColor(.orange)
                        }
                        
                        if allowPushNotifications {
                            VStack(spacing: 10) {
                                HStack {
                                    Text("赛事提醒")
                                        .font(.system(size: 15))
                                        .foregroundColor(.black)
                                    Spacer()
                                    Toggle("", isOn: $allowReminders)
                                        .foregroundColor(.orange)
                                }
                                
                                HStack {
                                    Text("成就通知")
                                        .font(.system(size: 15))
                                        .foregroundColor(.black)
                                    Spacer()
                                    Toggle("", isOn: $allowAchievementNotifications)
                                        .foregroundColor(.orange)
                                }
                                
                                HStack {
                                    Text("促销通知")
                                        .font(.system(size: 15))
                                        .foregroundColor(.black)
                                    Spacer()
                                    Toggle("", isOn: $allowPromotionalNotifications)
                                        .foregroundColor(.orange)
                                }
                            }
                            .padding(.leading, 20)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 通知声音
                    Section {
                        Button(action: { showSoundSettings() }) {
                            HStack {
                                Text("通知声音")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Text("默认")
                                    .font(.system(size: 15))
                                    .foregroundColor(.gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 通知样式
                    Section {
                        Button(action: { showStyleSettings() }) {
                            HStack {
                                Text("通知样式")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Text("横幅")
                                    .font(.system(size: 15))
                                    .foregroundColor(.gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("通知设置", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    dismiss()
                }
            )
        }
    }
    
    func showSoundSettings() {
        print("显示声音设置")
    }
    
    func showStyleSettings() {
        print("显示样式设置")
    }
}
