import SwiftUI

struct PrivacyPolicyView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("隐私政策")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.black)
                        .padding(.top, 20)
                    
                    Text("生效日期：2026年3月1日")
                        .font(.system(size: 14))
                        .foregroundColor(.gray)
                    
                    Section {
                        Text("1. 信息收集与使用")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("我们收集您的个人信息，包括但不限于：")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 您的手机号、微信或QQ账号信息，用于登录和身份验证")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 您上传的马拉松奖牌照片和相关文字信息")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 您的设备信息、IP地址和使用情况数据")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("2. 信息存储与保护")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("我们采取以下措施保护您的个人信息：")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 数据加密存储")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 访问权限控制")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 定期安全审计")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("3. 信息共享")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("我们不会向第三方共享您的个人信息，除非：")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 获得您的明确许可")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 遵守法律法规要求")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 保护我们的合法权益")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("4. 您的权利")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("您有权：")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 访问和修改您的个人信息")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 要求删除您的个人信息")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 注销您的账号")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("5. 隐私政策更新")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("我们可能会不时更新本隐私政策。当我们进行重大变更时，我们会通过应用内通知或电子邮件通知您。")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                    
                    Section {
                        Text("6. 联系我们")
                            .font(.system(size: 18, weight: .medium))
                            .foregroundColor(.black)
                        
                        Text("如果您对本隐私政策有任何疑问，请通过以下方式联系我们：")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 电子邮件：privacy@marathonapp.com")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                        
                        Text("- 客服电话：400-123-4567")
                            .font(.system(size: 16))
                            .foregroundColor(.black)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("隐私政策", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    dismiss()
                }
            )
        }
    }
}
