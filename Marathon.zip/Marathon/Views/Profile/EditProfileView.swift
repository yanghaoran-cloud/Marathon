import SwiftUI
import UIKit

struct EditProfileView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var user: User
    @State private var showImagePicker = false
    @State private var imagePickerSourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var tempAvatar: Data?
    @State private var tempNickname: String
    @State private var tempBio: String
    
    init(user: Binding<User>) {
        self._user = user
        self._tempNickname = State(initialValue: user.wrappedValue.nickname)
        self._tempBio = State(initialValue: user.wrappedValue.bio ?? "")
        self._tempAvatar = State(initialValue: user.wrappedValue.avatar)
    }
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 头像编辑
                    VStack {
                        ZStack {
                            if let avatarData = tempAvatar {
                                Image(uiImage: UIImage(data: avatarData) ?? UIImage(systemName: "person")!)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 100, height: 100)
                                    .cornerRadius(50)
                            } else {
                                Image(systemName: "person")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 100, height: 100)
                                    .foregroundColor(.orange)
                                    .background(Color.orange.opacity(0.1))
                                    .cornerRadius(50)
                            }
                            
                            // 编辑按钮
                            Button(action: { showImagePicker = true }) {
                                Image(systemName: "camera.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 24, height: 24)
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(Color.orange)
                                    .cornerRadius(16)
                                    .offset(x: 40, y: 40)
                            }
                        }
                        Text("点击更换头像")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                            .padding(.top, 8)
                    }
                    
                    // 昵称编辑
                    TextField("昵称", text: $tempNickname)
                        .padding(16)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    
                    // 简介编辑
                    VStack(alignment: .leading) {
                        TextEditor(text: $tempBio)
                            .padding(16)
                            .background(Color.orange.opacity(0.1))
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                            .frame(height: 120)
                        Text("\(tempBio.count)/50")
                            .font(.system(size: 12))
                            .foregroundColor(tempBio.count > 50 ? .red : .gray)
                            .padding(.horizontal, 36)
                    }
                    
                    // 保存按钮
                    Button(action: { saveChanges() }) {
                        Text("保存")
                            .foregroundColor(.white)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                    }
                }
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("编辑资料", displayMode: .inline)
            .navigationBarItems(
                leading: Button("取消") {
                    dismiss()
                }
            )
        }
        .sheet(isPresented: $showImagePicker) {
            ImagePicker(sourceType: $imagePickerSourceType, selectedImage: { imageData in
                if let imageData = imageData {
                    tempAvatar = imageData
                }
            })
        }
    }
    
    func saveChanges() {
        // 更新用户资料
        user.nickname = tempNickname
        // 限制简介字数不超过50字
        user.bio = tempBio.count > 50 ? String(tempBio.prefix(50)) : tempBio
        user.avatar = tempAvatar
        
        // 保存到数据服务
        DataService.shared.saveUser(user)
        
        // 关闭页面
        dismiss()
    }
}
