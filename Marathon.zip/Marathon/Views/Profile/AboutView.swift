import SwiftUI

struct AboutView: View {
    @State private var appVersion = "1.0.0"
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 应用图标和名称
                    VStack(spacing: 10) {
                        Image(systemName: "medal.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 80, height: 80)
                            .foregroundColor(.orange)
                        Text("Marathon")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.black)
                        Text("马拉松奖牌收藏与故事记录")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    .padding()
                    
                    // 版本信息
                    Section {
                        HStack {
                            Text("版本")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Text(appVersion)
                                .font(.system(size: 15))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 功能介绍
                    Section {
                        Text("功能介绍")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text("• 马拉松奖牌收藏与管理")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            Text("• AI辅助生成社交平台文案")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            Text("• 多平台分享支持")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                            Text("• 个人中心与次数管理")
                                .font(.system(size: 14))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 联系方式
                    Section {
                        Button(action: { showContact() }) {
                            HStack {
                                Text("联系方式")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                        
                        Button(action: { showFeedback() }) {
                            HStack {
                                Text("意见反馈")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 版权信息
                    Text("© 2026 Marathon. All rights reserved.")
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("关于我们", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    // 返回上一页
                }
            )
        }
    }
    
    func showContact() {
        print("联系方式")
    }
    
    func showFeedback() {
        print("意见反馈")
    }
}
