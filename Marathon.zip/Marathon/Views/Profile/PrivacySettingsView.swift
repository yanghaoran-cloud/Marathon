import SwiftUI

struct PrivacySettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var allowTracking = false
    @State private var allowPersonalizedAds = false
    @State private var allowDataSharing = false
    @State private var showConfirmDialog = false
    @State private var showPrivacyPolicyView = false
    @State private var showTermsOfServiceView = false
    var onLogoutSuccess: (() -> Void)? = nil
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 数据收集
                    Section {
                        HStack {
                            Text("允许应用跟踪")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Toggle("", isOn: $allowTracking)
                                .foregroundColor(.orange)
                        }
                        
                        HStack {
                            Text("个性化广告")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Toggle("", isOn: $allowPersonalizedAds)
                                .foregroundColor(.orange)
                        }
                        
                        HStack {
                            Text("数据共享")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Toggle("", isOn: $allowDataSharing)
                                .foregroundColor(.orange)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 隐私政策
                    Section {
                        Button(action: { showPrivacyPolicyView = true }) {
                            HStack {
                                Text("隐私政策")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                        
                        Button(action: { showTermsOfServiceView = true }) {
                            HStack {
                                Text("服务条款")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 注销账号
                    Button(action: { showConfirmDialog = true }) {
                        Text("注销账号")
                            .font(.system(size: 16))
                            .foregroundColor(.red)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.white)
                            .cornerRadius(12)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("隐私设置", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    dismiss()
                }
            )
        }
        .alert(isPresented: $showConfirmDialog) {
            Alert(
                title: Text("确认注销"),
                message: Text("注销账号后，所有数据将被删除，无法恢复。确定要继续吗？"),
                primaryButton: .destructive(Text("确定"), action: { logout() }),
                secondaryButton: .cancel()
            )
        }
        .fullScreenCover(isPresented: $showPrivacyPolicyView) {
            PrivacyPolicyView()
        }
        .fullScreenCover(isPresented: $showTermsOfServiceView) {
            TermsOfServiceView()
        }
    }
    
    func logout() {
        // 清除所有数据
        DataService.shared.clearAllData()
        // 重置AI使用次数
        DataService.shared.resetAIUsageCount()
        // 返回到启动页第一页
        print("账号已注销，数据已清零，返回启动页")
        // 调用回调
        onLogoutSuccess?()
    }
}
