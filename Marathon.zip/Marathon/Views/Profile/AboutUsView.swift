import SwiftUI

struct AboutUsView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 应用图标和名称
                    VStack(spacing: 10) {
                        Image(systemName: "medal.fill")
                            .font(.system(size: 80))
                            .foregroundColor(.orange)
                        Text("Marathon")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.black)
                        Text("马拉松奖牌收藏与故事记录工具")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                    .padding(.top, 40)
                    
                    // 版本信息
                    Section {
                        HStack {
                            Text("版本")
                                .font(.system(size: 16))
                                .foregroundColor(.black)
                            Spacer()
                            Text("1.0.0")
                                .font(.system(size: 15))
                                .foregroundColor(.gray)
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 功能介绍
                    Section {
                        Text("功能介绍")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Text("Marathon是一款专为马拉松爱好者设计的奖牌收藏与故事记录工具，帮助您记录每一次马拉松的精彩瞬间，生成精美的社交平台文案，与朋友分享您的跑步故事。")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                            .lineLimit(nil)
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 联系方式
                    Section {
                        Text("联系方式")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Button(action: { sendEmail() }) {
                            HStack {
                                Text("电子邮件")
                                    .font(.system(size: 14))
                                    .foregroundColor(.black)
                                Spacer()
                                Text("support@marathonapp.com")
                                    .font(.system(size: 14))
                                    .foregroundColor(.gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                        
                        Button(action: { makePhoneCall() }) {
                            HStack {
                                Text("客服电话")
                                    .font(.system(size: 14))
                                    .foregroundColor(.black)
                                Spacer()
                                Text("400-123-4567")
                                    .font(.system(size: 14))
                                    .foregroundColor(.gray)
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                    .padding()
                    .background(Color.white)
                    .cornerRadius(12)
                    
                    // 意见反馈
                    Button(action: { feedback() }) {
                        Text("意见反馈")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.white)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(12)
                    }
                    
                    // 版权信息
                    Text("© 2026 Marathon. All rights reserved.")
                        .font(.system(size: 12))
                        .foregroundColor(.gray)
                        .padding(.top, 40)
                        .padding(.bottom, 20)
                }
                .padding(.horizontal, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("关于我们", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    dismiss()
                }
            )
        }
    }
    
    func sendEmail() {
        print("发送邮件")
    }
    
    func makePhoneCall() {
        print("拨打电话")
    }
    
    func feedback() {
        print("意见反馈")
    }
}
