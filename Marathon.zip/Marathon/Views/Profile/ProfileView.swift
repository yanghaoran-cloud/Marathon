import SwiftUI

struct ProfileView: View {
    @State private var user: User?
    @State private var showRecharge = false
    @State private var showEditProfile = false
    var onLogoutSuccess: (() -> Void)? = nil
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 用户信息
                    UserInfoSection(user: $user, onEditProfile: { showEditProfile = true })
                    
                    // 次数管理
                    AIUsageSection()
                    
                    // 通用设置
                    SettingsSection(onLogoutSuccess: onLogoutSuccess)
                }
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("个人中心", displayMode: .inline)
        }
        .fullScreenCover(isPresented: $showRecharge) {
            RechargeView(isPresented: $showRecharge)
        }
        .fullScreenCover(isPresented: $showEditProfile) {
            // 总是尝试从本地加载用户数据，如果没有则创建新用户
            var userToEdit = DataService.shared.loadUser() ?? User(
                id: UUID().uuidString,
                nickname: "未登录用户",
                avatar: nil,
                bio: nil,
                aiUsageCount: 10,
                loginType: .guest,
                phoneNumber: nil,
                createdAt: Date()
            )
            EditProfileView(user: Binding(get: { userToEdit }, set: { 
                userToEdit = $0
                self.user = $0
                // 保存用户数据
                DataService.shared.saveUser($0)
            }))
        }
        .onAppear {
            loadUser()
        }
        .onChange(of: showEditProfile) { _ in
            // 当编辑资料页面关闭时，重新加载用户数据
            loadUser()
        }
    }
    
    func loadUser() {
        user = DataService.shared.loadUser()
    }
}

struct UserInfoSection: View {
    @Binding var user: User?
    var onEditProfile: (() -> Void)?
    
    var body: some View {
        VStack(spacing: 10) {
            // 头像
            if let avatarData = user?.avatar {
                Image(uiImage: UIImage(data: avatarData) ?? UIImage(systemName: "person")!)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 80, height: 80)
                    .cornerRadius(40)
            } else {
                Image(systemName: "person")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                    .foregroundColor(.orange)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(40)
            }
            
            // 昵称
            Text(user?.nickname ?? "未登录")
                .font(.system(size: 18, weight: .bold))
                .foregroundColor(.black)
            
            // 简介
            if let bio = user?.bio, !bio.isEmpty {
                Text(bio)
                    .font(.system(size: 14))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
                    .lineLimit(3) // 限制显示3行
            }
            
            // 登录方式
            Text(loginTypeText)
                .font(.system(size: 14))
                .foregroundColor(.gray)
            
            // 编辑资料按钮
            Button(action: { onEditProfile?() }) {
                Text("编辑资料")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.orange)
                    .padding(.vertical, 8)
                    .padding(.horizontal, 20)
                    .background(Color.orange.opacity(0.1))
                    .cornerRadius(16)
            }
            .padding(.top, 10)
        }
        .padding(.vertical, 20)
        .background(Color.white)
        .cornerRadius(12)
        .padding(.horizontal, 20)
    }
    
    var loginTypeText: String {
        switch user?.loginType {
        case .phone:
            return "手机号登录"
        case .wechat:
            return "微信登录"
        case .qq:
            return "QQ登录"
        case .guest:
            return "游客模式"
        default:
            return "未登录"
        }
    }
}

struct AIUsageSection: View {
    @State private var showRecharge = false
    @State private var aiUsageCount: Int = 0
    
    var body: some View {
        VStack(spacing: 10) {
            HStack {
                Text("AI使用次数")
                    .font(.system(size: 16, weight: .medium))
                    .foregroundColor(.black)
                Spacer()
                Text("\(aiUsageCount) 次")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundColor(.orange)
            }
            
            Button(action: { showRecharge = true }) {
                Text("充值AI次数")
                    .foregroundColor(.white)
                    .padding(.vertical, 12)
                    .frame(maxWidth: .infinity)
                    .background(Color.orange)
                    .cornerRadius(12)
            }
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(12)
        .padding(.horizontal, 20)
        .fullScreenCover(isPresented: $showRecharge) {
            RechargeView(isPresented: $showRecharge)
        }
        .onAppear {
            updateAIUsageCount()
        }
        .onChange(of: showRecharge) { _ in
            // 当从充值页面返回时，更新AI使用次数
            updateAIUsageCount()
        }
    }
    
    func updateAIUsageCount() {
        if DataService.shared.isLoggedIn() {
            aiUsageCount = DataService.shared.getAIUsageCount()
        } else {
            aiUsageCount = 0
        }
    }
}

struct SettingsSection: View {
    @State private var showPrivacySettings = false
    @State private var showNotificationSettings = false
    @State private var showCacheClean = false
    @State private var showAccountSecurity = false
    @State private var showAbout = false
    var onLogoutSuccess: (() -> Void)? = nil
    
    var body: some View {
        VStack(spacing: 0) {
            SettingItem(title: "隐私设置", icon: "lock", action: { showPrivacySettings = true })
            SettingItem(title: "通知设置", icon: "bell", action: { showNotificationSettings = true })
            SettingItem(title: "缓存清理", icon: "trash", action: { showCacheClean = true })
            SettingItem(title: "账号安全", icon: "shield", action: { showAccountSecurity = true })
            SettingItem(title: "关于我们", icon: "info.circle", action: { showAbout = true })
        }
        .background(Color.white)
        .cornerRadius(12)
        .padding(.horizontal, 20)
        .fullScreenCover(isPresented: $showPrivacySettings) {
            PrivacySettingsView {
                // 注销成功，返回启动页
                print("注销成功，返回启动页")
                onLogoutSuccess?()
            }
        }
        .fullScreenCover(isPresented: $showNotificationSettings) {
            NotificationSettingsView()
        }
        .fullScreenCover(isPresented: $showCacheClean) {
                CacheCleanupView()
            }
            .fullScreenCover(isPresented: $showAccountSecurity) {
                AccountSecurityView()
            }
            .fullScreenCover(isPresented: $showAbout) {
                AboutUsView()
            }
    }
}

struct SettingItem: View {
    let title: String
    let icon: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.orange)
                Text(title)
                    .font(.system(size: 16))
                    .foregroundColor(.black)
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding(20)
            .border(Color.orange.opacity(0.1))
        }
    }
}
