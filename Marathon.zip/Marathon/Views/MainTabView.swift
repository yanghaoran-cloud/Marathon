import SwiftUI

struct MainTabView: View {
    @State private var showOnboardingView = false
    var onLogout: (() -> Void)? = nil
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("首页")
                }
            
            AddMedalView()
                .tabItem {
                    Image(systemName: "plus.circle.fill")
                    Text("添加")
                }
            
            AIChatView()
                .tabItem {
                    Image(systemName: "brain.fill")
                    Text("AI助手")
                }
            
            ProfileView { 
                // 注销成功，返回启动页
                showOnboardingView = true
                onLogout?()
            }
                .tabItem {
                    Image(systemName: "person.fill")
                    Text("我的")
                }
        }
        .accentColor(.orange)
        .fullScreenCover(isPresented: $showOnboardingView) {
            OnboardingView()
        }
    }
    
    func handleLogout() {
        showOnboardingView = true
    }
}
