import SwiftUI

struct PhoneVerificationView: View {
    @Binding var isPresented: Bool
    @State private var phoneNumber: String = ""
    @State private var verificationCode: String = ""
    @State private var isLoading: Bool = false
    @State private var countdown: Int = 0
    @State private var showError: Bool = false
    @State private var errorMessage: String = ""
    var onLoginSuccess: (() -> Void)? = nil
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 标题
                    Text("手机验证码登录")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.black)
                    
                    // 手机号输入
                    VStack(alignment: .leading, spacing: 8) {
                        Text("手机号")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                        HStack {
                            TextField("请输入手机号", text: $phoneNumber)
                                .keyboardType(.phonePad)
                                .font(.system(size: 16))
                                .padding(16)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(12)
                                .frame(maxWidth: .infinity)
                        }
                    }
                    
                    // 验证码输入
                    VStack(alignment: .leading, spacing: 8) {
                        Text("验证码")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.black)
                        HStack(spacing: 12) {
                            TextField("请输入验证码", text: $verificationCode)
                                .keyboardType(.numberPad)
                                .font(.system(size: 16))
                                .padding(16)
                                .background(Color.gray.opacity(0.1))
                                .cornerRadius(12)
                                .frame(maxWidth: .infinity)
                            Button(action: { sendVerificationCode() }) {
                                Text(countdown > 0 ? "\(countdown)s" : "获取验证码")
                                    .font(.system(size: 14, weight: .medium))
                                    .foregroundColor(countdown > 0 ? .gray : .orange)
                                    .padding(16)
                                    .background(Color.gray.opacity(0.1))
                                    .cornerRadius(12)
                            }
                            .disabled(countdown > 0 || phoneNumber.count != 11)
                        }
                    }
                    
                    // 登录按钮
                    Button(action: { verifyCode() }) {
                        Text(isLoading ? "登录中..." : "登录")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundColor(.white)
                            .padding(16)
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(12)
                    }
                    .disabled(isLoading || phoneNumber.count != 11 || verificationCode.count != 6)
                }
                .padding(.horizontal, 20)
                .padding(.top, 40)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("验证码登录", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    isPresented = false
                }
            )
            .alert(isPresented: $showError) {
                Alert(title: Text("错误"), message: Text(errorMessage), dismissButton: .default(Text("确定")))
            }
        }
    }
    
    func sendVerificationCode() {
        // 验证手机号格式
        if phoneNumber.count != 11 {
            errorMessage = "请输入正确的手机号"
            showError = true
            return
        }
        
        // 开始倒计时
        countdown = 60
        startCountdown()
        
        // 模拟发送验证码
        print("发送验证码到 phoneNumber)")
        // 实际应用中，这里应该调用后端API发送验证码
    }
    
    func startCountdown() {
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            if countdown > 0 {
                countdown -= 1
            } else {
                timer.invalidate()
            }
        }
    }
    
    func verifyCode() {
        isLoading = true
        
        // 模拟验证验证码
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            // 实际应用中，这里应该调用后端API验证验证码
            print("验证验证码 verificationCode) 对于手机号 phoneNumber)")
            
            // 模拟验证成功
            isLoading = false
            
            // 创建用户并保存
            let user = User(id: UUID().uuidString, nickname: "用户" + phoneNumber.suffix(4), loginType: .phone, phoneNumber: phoneNumber, createdAt: Date())
            DataService.shared.saveUser(user)
            
            // 登录成功，返回
            isPresented = false
            onLoginSuccess?()
        }
    }
}
