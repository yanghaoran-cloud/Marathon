import SwiftUI

struct LoginView: View {
    @Binding var isPresented: Bool
    @State private var showPhoneVerification: Bool = false
    var onLoginSuccess: (() -> Void)? = nil
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 标题
                    Text("登录")
                        .font(.system(size: 24, weight: .bold))
                        .foregroundColor(.black)
                    
                    // 登录方式
                    VStack(spacing: 12) {
                        Button(action: { showPhoneVerification = true }) {
                            HStack {
                                Image(systemName: "phone")
                                    .font(.system(size: 20))
                                    .foregroundColor(.orange)
                                Text("手机号登录")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                            .padding(16)
                            .background(Color.white)
                            .cornerRadius(12)
                            .shadow(radius: 2)
                        }
                        
                        Button(action: { loginWithWechat() }) {
                            HStack {
                                Image(systemName: "person.fill")
                                    .font(.system(size: 20))
                                    .foregroundColor(.green)
                                Text("微信登录")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                            .padding(16)
                            .background(Color.white)
                            .cornerRadius(12)
                            .shadow(radius: 2)
                        }
                        
                        Button(action: { loginWithQQ() }) {
                            HStack {
                                Image(systemName: "person.2.fill")
                                    .font(.system(size: 20))
                                    .foregroundColor(.blue)
                                Text("QQ登录")
                                    .font(.system(size: 16))
                                    .foregroundColor(.black)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                            .padding(16)
                            .background(Color.white)
                            .cornerRadius(12)
                            .shadow(radius: 2)
                        }
                    }
                    
                    // 游客模式
                    Button(action: { loginAsGuest() }) {
                        Text("游客模式")
                            .font(.system(size: 14))
                            .foregroundColor(.gray)
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 40)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("登录", displayMode: .inline)
            .navigationBarItems(
                leading: Button("返回") {
                    isPresented = false
                }
            )
            .sheet(isPresented: $showPhoneVerification) {
                PhoneVerificationView(isPresented: $showPhoneVerification, onLoginSuccess: onLoginSuccess)
            }
        }
    }
    
    func loginWithWechat() {
        print("微信登录")
        let user = User(id: UUID().uuidString, nickname: "微信用户", loginType: .wechat, createdAt: Date())
        DataService.shared.saveUser(user)
        isPresented = false
        onLoginSuccess?()
    }
    
    func loginWithQQ() {
        print("QQ登录")
        let user = User(id: UUID().uuidString, nickname: "QQ用户", loginType: .qq, createdAt: Date())
        DataService.shared.saveUser(user)
        isPresented = false
        onLoginSuccess?()
    }
    
    func loginAsGuest() {
        print("游客模式")
        var user = User(id: UUID().uuidString, nickname: "游客", loginType: .guest, createdAt: Date())
        user.aiUsageCount = 10 // 游客模式AI次数为10次
        DataService.shared.saveUser(user)
        isPresented = false
        onLoginSuccess?()
    }
}
