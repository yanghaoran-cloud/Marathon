import SwiftUI
import UIKit

struct AddMedalView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var imageData: Data?
    @State private var title: String = ""
    @State private var description: String = ""
    @State private var showImagePicker = false
    @State private var imagePickerSourceType: UIImagePickerController.SourceType = .photoLibrary
    @State private var isAIProcessing = false
    @State private var isSaved = false
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    // 奖牌照片选择
                    ZStack {
                        if let imageData = imageData {
                            Image(uiImage: UIImage(data: imageData) ?? UIImage(systemName: "medal")!)
                                .resizable()
                                .aspectRatio(1, contentMode: .fit)
                                .cornerRadius(12)
                                .padding(.horizontal, 20)
                        } else {
                            VStack(spacing: 10) {
                                Image(systemName: "camera.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 50, height: 50)
                                    .foregroundColor(.orange)
                                Text("点击拍照或选择图片")
                                    .font(.system(size: 16))
                                    .foregroundColor(.gray)
                            }
                            .padding(.vertical, 60)
                            .background(Color.orange.opacity(0.1))
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                        }
                    }
                    .onTapGesture {
                        // 直接从相册选择图片
                        imagePickerSourceType = .photoLibrary
                        showImagePicker = true
                    }
                    .sheet(isPresented: $showImagePicker) {
                        ImagePicker(sourceType: $imagePickerSourceType, selectedImage: $imageData)
                    }
                    
                    // AI画面修复
                    if imageData != nil {
                        Button(action: { enhanceImage() }) {
                            HStack {
                                Image(systemName: "wand.and.stars")
                                    .foregroundColor(.orange)
                                Text("AI画面修复")
                                    .foregroundColor(.orange)
                                    .font(.system(size: 16, weight: .medium))
                            }
                            .padding(.vertical, 12)
                            .frame(maxWidth: .infinity)
                            .background(Color.orange.opacity(0.1))
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                        }
                    }
                    
                    // 标题编辑
                    TextField("奖牌标题", text: $title)
                        .padding(16)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    
                    // 描述编辑
                    TextEditor(text: $description)
                        .padding(16)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                        .frame(height: 150)
                    
                    // AI文案优化
                    Button(action: { optimizeCopywriting() }) {
                        HStack {
                            Image(systemName: "brain")
                                .foregroundColor(.orange)
                            Text("AI文案优化")
                                .foregroundColor(.orange)
                                .font(.system(size: 16, weight: .medium))
                        }
                        .padding(.vertical, 12)
                        .frame(maxWidth: .infinity)
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                        .padding(.horizontal, 20)
                    }
                    
                    // 保存按钮
                    Button(action: { saveMedal() }) {
                        Text("保存")
                            .foregroundColor(.white)
                            .padding(.vertical, 16)
                            .frame(maxWidth: .infinity)
                            .background(Color.orange)
                            .cornerRadius(12)
                            .padding(.horizontal, 20)
                    }
                }
                .padding(.top, 20)
                .padding(.bottom, 40)
            }
            .navigationBarTitle("添加奖牌", displayMode: .inline)
            .navigationBarItems(
                leading: Button("取消") {
                    // 取消添加，返回上一页
                    print("取消添加，返回上一页")
                    dismiss()
                }
            )
        }
        .overlay {
            if isAIProcessing {
                ZStack {
                    Color.black.opacity(0.5)
                    VStack {
                        ProgressView()
                        Text("AI处理中...")
                            .foregroundColor(.white)
                            .padding(.top, 10)
                    }
                }
                .ignoresSafeArea()
            }
        }
        .fullScreenCover(isPresented: $isSaved) {
            // 保存成功后的提示
            VStack {
                Image(systemName: "checkmark.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .foregroundColor(.green)
                Text("保存成功！")
                    .font(.system(size: 20, weight: .bold))
                    .foregroundColor(.black)
                Button("确定") {
                    isSaved = false
                }
                .padding(.top, 20)
                .foregroundColor(.orange)
            }
            .padding()
        }
    }
    
    func enhanceImage() {
        guard imageData != nil else { return }
        
        // 检查AI次数
        if !DataService.shared.decreaseAIUsageCount() {
            print("AI次数不足")
            return
        }
        
        isAIProcessing = true
        
        // 模拟AI画面修复
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            isAIProcessing = false
            print("AI画面修复完成")
        }
    }
    
    func optimizeCopywriting() {
        // 检查AI次数
        if !DataService.shared.decreaseAIUsageCount() {
            print("AI次数不足")
            return
        }
        
        isAIProcessing = true
        
        // 模拟AI文案优化
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            description = "AI优化后的文案：\n" + description
            isAIProcessing = false
            print("AI文案优化完成")
        }
    }
    
    func saveMedal() {
        guard let imageData = imageData, !title.isEmpty else {
            print("请填写标题并选择图片")
            return
        }
        
        // 创建新奖牌
        let newMedal = Medal(
            title: title,
            description: description,
            imageData: imageData,
            createdAt: Date()
        )
        
        // 保存到数据服务
        var medals = DataService.shared.loadMedals()
        medals.append(newMedal)
        DataService.shared.saveMedals(medals)
        
        // 显示保存成功提示
        isSaved = true
        
        // 重置表单
        self.imageData = nil
        self.title = ""
        self.description = ""
    }
}
