import SwiftUI
import UIKit

struct ImagePicker: UIViewControllerRepresentable {
    @Binding var sourceType: UIImagePickerController.SourceType
    @Binding var selectedImage: Data?
    let selectedImageCallback: ((Data?) -> Void)?
    @Environment(\.presentationMode) var presentationMode
    
    init(sourceType: Binding<UIImagePickerController.SourceType>, selectedImage: Binding<Data?>) {
        self._sourceType = sourceType
        self._selectedImage = selectedImage
        self.selectedImageCallback = nil
    }
    
    init(sourceType: Binding<UIImagePickerController.SourceType>, selectedImage: @escaping (Data?) -> Void) {
        self._sourceType = sourceType
        self._selectedImage = Binding<Data?>(get: { nil }, set: { _ in })
        self.selectedImageCallback = selectedImage
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = sourceType
        imagePicker.delegate = context.coordinator
        return imagePicker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
        uiViewController.sourceType = sourceType
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        let parent: ImagePicker
        
        init(_ parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                if let imageData = image.jpegData(compressionQuality: 0.8) {
                    parent.selectedImage = imageData
                    parent.selectedImageCallback?(imageData)
                }
            }
            parent.presentationMode.wrappedValue.dismiss()
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            parent.presentationMode.wrappedValue.dismiss()
        }
    }
}
