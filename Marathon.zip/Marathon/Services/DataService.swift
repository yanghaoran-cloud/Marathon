import Foundation

class DataService {
    static let shared = DataService()
    
    private let userKey = "user"
    private let medalsKey = "medals"
    private let medalsFileName = "medals.json"
    
    private init() {
        // 清理UserDefaults中的medals数据
        UserDefaults.standard.removeObject(forKey: medalsKey)
    }
    
    // 保存用户数据
    func saveUser(_ user: User) {
        print("开始保存用户数据：\(user.nickname)")
        if let data = try? JSONEncoder().encode(user) {
            print("保存数据大小：\(data.count) 字节")
            UserDefaults.standard.set(data, forKey: userKey)
            print("保存成功")
        } else {
            print("保存失败：编码用户数据失败")
        }
    }
    
    // 加载用户数据
    func loadUser() -> User? {
        print("开始加载用户数据")
        if let data = UserDefaults.standard.data(forKey: userKey) {
            print("加载数据大小：\(data.count) 字节")
            if let user = try? JSONDecoder().decode(User.self, from: data) {
                print("加载成功：\(user.nickname)")
                return user
            } else {
                print("加载失败：解码用户数据失败")
            }
        } else {
            print("加载失败：没有找到用户数据")
        }
        return nil
    }
    
    // 保存奖牌数据
    func saveMedals(_ medals: [Medal]) {
        do {
            let data = try JSONEncoder().encode(medals)
            let url = getDocumentsDirectory().appendingPathComponent(medalsFileName)
            try data.write(to: url)
        } catch {
            print("保存奖牌数据失败: \(error)")
        }
    }
    
    // 加载奖牌数据
    func loadMedals() -> [Medal] {
        do {
            let url = getDocumentsDirectory().appendingPathComponent(medalsFileName)
            let data = try Data(contentsOf: url)
            let medals = try JSONDecoder().decode([Medal].self, from: data)
            return medals
        } catch {
            print("加载奖牌数据失败: \(error)")
            return []
        }
    }
    
    // 从后端获取奖牌数据
    func fetchMedalsFromBackend(completion: @escaping (Result<[Medal], Error>) -> Void) {
        if let user = loadUser() {
            BackendService.shared.getMedals(userId: user.id) { result in
                switch result {
                case .success(let medals):
                    // 保存到本地
                    self.saveMedals(medals)
                    completion(.success(medals))
                case .failure(let error):
                    // 失败时返回本地数据
                    completion(.success(self.loadMedals()))
                    print("从后端获取奖牌数据失败：\(error)")
                }
            }
        } else {
            completion(.success(self.loadMedals()))
        }
    }
    
    // 向后端添加奖牌
    func addMedalToBackend(_ medal: Medal, completion: @escaping (Result<Medal, Error>) -> Void) {
        if let user = loadUser() {
            BackendService.shared.addMedal(userId: user.id, medal: medal) { result in
                switch result {
                case .success(let addedMedal):
                    // 更新本地数据
                    var medals = self.loadMedals()
                    medals.append(addedMedal)
                    self.saveMedals(medals)
                    completion(.success(addedMedal))
                case .failure(let error):
                    completion(.failure(error))
                    print("向后端添加奖牌失败：\(error)")
                }
            }
        } else {
            // 未登录时直接保存到本地
            var medals = self.loadMedals()
            medals.append(medal)
            self.saveMedals(medals)
            completion(.success(medal))
        }
    }
    
    // 向后端更新奖牌
    func updateMedalToBackend(_ medal: Medal, completion: @escaping (Result<Medal, Error>) -> Void) {
        if let user = loadUser() {
            BackendService.shared.updateMedal(userId: user.id, medal: medal) { result in
                switch result {
                case .success(let updatedMedal):
                    // 更新本地数据
                    var medals = self.loadMedals()
                    if let index = medals.firstIndex(where: { $0.id == medal.id }) {
                        medals[index] = updatedMedal
                        self.saveMedals(medals)
                    }
                    completion(.success(updatedMedal))
                case .failure(let error):
                    completion(.failure(error))
                    print("向后端更新奖牌失败：\(error)")
                }
            }
        } else {
            // 未登录时直接更新本地数据
            var medals = self.loadMedals()
            if let index = medals.firstIndex(where: { $0.id == medal.id }) {
                medals[index] = medal
                self.saveMedals(medals)
            }
            completion(.success(medal))
        }
    }
    
    // 向后端删除奖牌
    func deleteMedalFromBackend(_ medalId: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        if let user = loadUser() {
            BackendService.shared.deleteMedal(userId: user.id, medalId: medalId) { result in
                switch result {
                case .success(_):
                    // 更新本地数据
                    var medals = self.loadMedals()
                    if let medalUUID = UUID(uuidString: medalId) {
                        medals.removeAll { $0.id == medalUUID }
                        self.saveMedals(medals)
                    }
                    completion(.success(true))
                case .failure(let error):
                    completion(.failure(error))
                    print("向后端删除奖牌失败：\(error)")
                }
            }
        } else {
            // 未登录时直接删除本地数据
            var medals = self.loadMedals()
            if let medalUUID = UUID(uuidString: medalId) {
                medals.removeAll { $0.id == medalUUID }
                self.saveMedals(medals)
            }
            completion(.success(true))
        }
    }
    
    // 获取文档目录
    private func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    // 增加AI使用次数
    func addAIUsageCount(_ count: Int) {
        if var user = loadUser() {
            user.aiUsageCount += count
            saveUser(user)
            
            // 同步到后端
            BackendService.shared.rechargeAIUsageCount(userId: user.id, count: count, amount: 0) { _ in
                // 忽略结果
            }
        }
    }
    
    // 减少AI使用次数
    func decreaseAIUsageCount() -> Bool {
        if var user = loadUser() {
            if user.aiUsageCount > 0 {
                user.aiUsageCount -= 1
                saveUser(user)
                
                // 同步到后端
                BackendService.shared.deductAIUsageCount(userId: user.id, count: 1) { _ in
                    // 忽略结果
                }
                
                return true
            }
        }
        return false
    }
    
    // 从后端获取AI使用次数
    func fetchAIUsageCountFromBackend(completion: @escaping (Result<Int, Error>) -> Void) {
        if let user = loadUser() {
            BackendService.shared.getUserInfo(userId: user.id) { result in
                switch result {
                case .success(let updatedUser):
                    // 更新本地用户数据
                    self.saveUser(updatedUser)
                    completion(.success(updatedUser.aiUsageCount))
                case .failure(let error):
                    // 失败时返回本地数据
                    completion(.success(self.getAIUsageCount()))
                    print("从后端获取AI使用次数失败：\(error)")
                }
            }
        } else {
            completion(.success(self.getAIUsageCount()))
        }
    }
    
    // 获取当前AI使用次数
    func getAIUsageCount() -> Int {
        if let user = loadUser() {
            return user.aiUsageCount
        }
        return 10 // 未登录时返回10次
    }
    
    // 充值AI次数
    func rechargeAIUsageCount(count: Int, amount: Double, completion: @escaping (Result<Int, Error>) -> Void) {
        if let user = loadUser() {
            BackendService.shared.rechargeAIUsageCount(userId: user.id, count: count, amount: amount) { result in
                switch result {
                case .success(let newCount):
                    // 更新本地用户数据
                    var updatedUser = user
                    updatedUser.aiUsageCount = newCount
                    self.saveUser(updatedUser)
                    completion(.success(newCount))
                case .failure(let error):
                    completion(.failure(error))
                    print("充值AI次数失败：\(error)")
                }
            }
        } else {
            // 未登录时直接增加本地次数
            let newCount = self.getAIUsageCount() + count
            if var user = self.loadUser() {
                user.aiUsageCount = newCount
                self.saveUser(user)
            }
            completion(.success(newCount))
        }
    }
    
    // 重置AI使用次数
    func resetAIUsageCount() {
        if var user = loadUser() {
            user.aiUsageCount = 10 // 重置为默认的10次
            saveUser(user)
        }
    }
    
    // 清除所有数据
    func clearAllData() {
        // 清除用户数据
        UserDefaults.standard.removeObject(forKey: userKey)
        
        // 清除奖牌数据
        do {
            let url = getDocumentsDirectory().appendingPathComponent(medalsFileName)
            if FileManager.default.fileExists(atPath: url.path) {
                try FileManager.default.removeItem(at: url)
            }
        } catch {
            print("清除奖牌数据失败: \(error)")
        }
    }
    
    // 检查是否已登录
    func isLoggedIn() -> Bool {
        return loadUser() != nil
    }
}
