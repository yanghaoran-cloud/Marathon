import Foundation

class BackendService {
    static let shared = BackendService()
    
    // 模拟API基础URL
    private let baseURL = "https://api.marathon.com"
    
    // 模拟网络延迟
    private let networkDelay: TimeInterval = 0.5
    
    // 模拟用户数据
    private var users: [String: User] = [:]
    
    // 模拟奖牌数据
    private var medals: [String: [Medal]] = [:]
    
    // 初始化
    init() {
        // 初始化模拟数据
        initializeMockData()
    }
    
    // 初始化模拟数据
    private func initializeMockData() {
        // 创建测试用户
        let testUser = User(
            id: UUID().uuidString,
            nickname: "测试用户",
            aiUsageCount: 10,
            loginType: .wechat,
            createdAt: Date()
        )
        users["1"] = testUser
        
        // 创建测试奖牌
        let testMedals: [Medal] = [
            Medal(
                id: UUID(),
                title: "北京马拉松",
                description: "2026年北京马拉松",
                imageData: Data(),
                createdAt: Date()
            ),
            Medal(
                id: UUID(),
                title: "上海马拉松",
                description: "2026年上海马拉松",
                imageData: Data(),
                createdAt: Date()
            )
        ]
        medals["1"] = testMedals
    }
    
    // 登录API
    func login(phoneNumber: String, verificationCode: String, completion: @escaping (Result<User, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            // 模拟验证
            if verificationCode == "123456" {
                // 创建用户
                let user = User(
                    id: UUID().uuidString,
                    nickname: "用户phoneNumber.suffix(4))",
                    aiUsageCount: 10,
                    loginType: .phone,
                    phoneNumber: phoneNumber,
                    createdAt: Date()
                )
                self.users[user.id] = user
                completion(.success(user))
            } else {
                completion(.failure(NSError(domain: "BackendService", code: 401, userInfo: [NSLocalizedDescriptionKey: "验证码错误"])))
            }
        }
    }
    
    // 微信登录API
    func loginWithWechat(completion: @escaping (Result<User, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            // 创建用户
            let user = User(
                id: UUID().uuidString,
                nickname: "微信用户",
                aiUsageCount: 10,
                loginType: .wechat,
                createdAt: Date()
            )
            self.users[user.id] = user
            completion(.success(user))
        }
    }
    
    // QQ登录API
    func loginWithQQ(completion: @escaping (Result<User, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            // 创建用户
            let user = User(
                id: UUID().uuidString,
                nickname: "QQ用户",
                aiUsageCount: 10,
                loginType: .qq,
                createdAt: Date()
            )
            self.users[user.id] = user
            completion(.success(user))
        }
    }
    
    // 获取用户信息API
    func getUserInfo(userId: String, completion: @escaping (Result<User, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            if let user = self.users[userId] {
                completion(.success(user))
            } else {
                completion(.failure(NSError(domain: "BackendService", code: 404, userInfo: [NSLocalizedDescriptionKey: "用户不存在"])))
            }
        }
    }
    
    // 获取奖牌列表API
    func getMedals(userId: String, completion: @escaping (Result<[Medal], Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            let userMedals = self.medals[userId] ?? []
            completion(.success(userMedals))
        }
    }
    
    // 添加奖牌API
    func addMedal(userId: String, medal: Medal, completion: @escaping (Result<Medal, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            var userMedals = self.medals[userId] ?? []
            userMedals.append(medal)
            self.medals[userId] = userMedals
            completion(.success(medal))
        }
    }
    
    // 更新奖牌API
    func updateMedal(userId: String, medal: Medal, completion: @escaping (Result<Medal, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            if var userMedals = self.medals[userId] {
                if let index = userMedals.firstIndex(where: { $0.id == medal.id }) {
                    userMedals[index] = medal
                    self.medals[userId] = userMedals
                    completion(.success(medal))
                } else {
                    completion(.failure(NSError(domain: "BackendService", code: 404, userInfo: [NSLocalizedDescriptionKey: "奖牌不存在"])))
                }
            } else {
                completion(.failure(NSError(domain: "BackendService", code: 404, userInfo: [NSLocalizedDescriptionKey: "用户不存在"])))
            }
        }
    }
    
    // 删除奖牌API
    func deleteMedal(userId: String, medalId: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            if var userMedals = self.medals[userId] {
                if let medalUUID = UUID(uuidString: medalId) {
                    userMedals.removeAll { $0.id == medalUUID }
                    self.medals[userId] = userMedals
                    completion(.success(true))
                } else {
                    completion(.failure(NSError(domain: "BackendService", code: 400, userInfo: [NSLocalizedDescriptionKey: "无效的奖牌ID"])))
                }
            } else {
                completion(.failure(NSError(domain: "BackendService", code: 404, userInfo: [NSLocalizedDescriptionKey: "用户不存在"])))
            }
        }
    }
    
    // 充值AI次数API
    func rechargeAIUsageCount(userId: String, count: Int, amount: Double, completion: @escaping (Result<Int, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            if var user = self.users[userId] {
                user.aiUsageCount += count
                self.users[userId] = user
                completion(.success(user.aiUsageCount))
            } else {
                completion(.failure(NSError(domain: "BackendService", code: 404, userInfo: [NSLocalizedDescriptionKey: "用户不存在"])))
            }
        }
    }
    
    // 扣除AI次数API
    func deductAIUsageCount(userId: String, count: Int, completion: @escaping (Result<Int, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            if var user = self.users[userId] {
                if user.aiUsageCount >= count {
                    user.aiUsageCount -= count
                    self.users[userId] = user
                    completion(.success(user.aiUsageCount))
                } else {
                    completion(.failure(NSError(domain: "BackendService", code: 400, userInfo: [NSLocalizedDescriptionKey: "AI次数不足"])))
                }
            } else {
                completion(.failure(NSError(domain: "BackendService", code: 404, userInfo: [NSLocalizedDescriptionKey: "用户不存在"])))
            }
        }
    }
    
    // 发送验证码API
    func sendVerificationCode(phoneNumber: String, completion: @escaping (Result<Bool, Error>) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + networkDelay) {
            // 模拟发送成功
            print("发送验证码到 phoneNumber)，验证码为：123456")
            completion(.success(true))
        }
    }
}
