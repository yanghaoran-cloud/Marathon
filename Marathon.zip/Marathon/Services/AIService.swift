import Foundation

class AIService {
    static let shared = AIService()
    
    private let apiToken = "pat_905NV4OdrzYiccaMfjRIMJYVh3p6J0CeyznDzOY7LttzaDHP8aLrMxVH53USX4x6"
    private let botId = "7619653767931183154"
    private let conversationsFileName = "conversations.json"
    
    // 对话管理
    private var conversations: [Conversation] = []
    private var currentConversationIndex: Int = 0
    
    // 对话结构
    struct Conversation: Codable {
        let id: String
        var title: String
        let createdAt: Date
        var messages: [[String: Any]]
        
        // 初始化方法
        init(id: String, title: String, createdAt: Date, messages: [[String: Any]]) {
            self.id = id
            self.title = title
            self.createdAt = createdAt
            self.messages = messages
        }
        
        // 编码方法
        func encode(to encoder: Encoder) throws {
            var container = encoder.container(keyedBy: CodingKeys.self)
            try container.encode(id, forKey: .id)
            try container.encode(title, forKey: .title)
            try container.encode(createdAt, forKey: .createdAt)
            // 直接编码messages数组，使用JSONEncoder的默认行为
            let messagesData = try JSONSerialization.data(withJSONObject: messages, options: [])
            try container.encode(messagesData, forKey: .messages)
        }
        
        // 解码方法
        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            id = try container.decode(String.self, forKey: .id)
            title = try container.decode(String.self, forKey: .title)
            createdAt = try container.decode(Date.self, forKey: .createdAt)
            // 直接解码messages数组
            let messagesData = try container.decode(Data.self, forKey: .messages)
            if let messagesArray = try JSONSerialization.jsonObject(with: messagesData, options: []) as? [[String: Any]] {
                messages = messagesArray
            } else {
                messages = []
            }
        }
        
        enum CodingKeys: String, CodingKey {
            case id, title, createdAt, messages
        }
    }
    
    // 最大对话历史长度（可根据token限制调整）
    private let maxHistoryLength = 50
    
    private init() {
        // 初始化时加载保存的对话列表
        loadConversations()
        // 如果没有对话，创建一个默认对话
        if conversations.isEmpty {
            _ = createNewConversation()
        }
    }
    
    // 知识库（用于RAG检索增强）
    private let knowledgeBase: [String] = [
        "马拉松比赛的标准距离是42.195公里",
        "无锡马拉松通常在每年的3月或4月举行",
        "PB是Personal Best的缩写，指个人最好成绩",
        "全马破3指的是全程马拉松用时在3小时以内",
        "马拉松训练通常包括长距离跑、速度训练和恢复跑",
        "跑前热身和跑后拉伸对预防 injury很重要",
        "合理的配速策略是马拉松比赛成功的关键",
        "比赛中的补给应该包括水分、电解质和碳水化合物",
        "训练计划应该根据个人的体能水平和目标进行调整",
        "充分的休息和恢复对提高成绩同样重要"
    ]
    
    // AI画面修复提示词
    func getImageEnhancementPrompt() -> String {
        return "请对这张马拉松奖牌照片进行以下处理：1. 提高清晰度和细节 2. 减少噪点 3. 优化色彩平衡 4. 增强奖牌的金属质感 5. 确保背景干净整洁"
    }
    
    // AI文案优化提示词
    func getCopywritingOptimizationPrompt(originalText: String) -> String {
        return "请优化以下马拉松奖牌故事文案，保留核心情感，提高语句流畅度，增加马拉松相关的氛围感：\n\n\(originalText)"
    }
    
    // 小红书文案生成提示词
    func getXiaohongshuPrompt(title: String, description: String) -> String {
        return "请为以下马拉松奖牌创建一篇小红书风格的图文文案，包含吸引人的标题、生动的正文和相关的话题标签：\n\n标题：\(title)\n描述：\(description)\n\n要求：1. 风格活泼有感染力 2. 突出马拉松精神 3. 加入适当的emoji 4. 包含至少3个相关话题标签"
    }
    
    // 模拟AI处理（实际项目中会调用真实的AI API）
    func processWithAI(prompt: String, completion: @escaping (String) -> Void) {
        // 模拟网络延迟
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
            // 模拟AI响应
            let response = "AI处理结果：\n" + prompt.prefix(50) + "..."
            completion(response)
        }
    }
    
    // 提取关键词
    private func extractKeywords(from text: String) -> [String] {
        // 简单的关键词提取，实际项目中可以使用更复杂的NLP方法
        let stopWords = Set(["的", "了", "是", "在", "我", "有", "和", "就", "不", "人", "都", "一", "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着", "没有", "看", "好", "自己", "这"])
        let words = text.components(separatedBy: CharacterSet.alphanumerics.inverted)
            .filter { !$0.isEmpty && !stopWords.contains($0.lowercased()) && $0.count > 1 }
        return Array(words.prefix(10)) // 只取前10个关键词
    }
    
    // 总结对话历史
    private func summarizeConversationHistory() -> String {
        let currentMessages = self.currentConversationMessages
        if currentMessages.isEmpty {
            return ""
        }
        
        // 只取最近的5条消息进行总结
        let recentMessages = Array(currentMessages.suffix(5))
        var summary = "对话历史总结：\n"
        
        for message in recentMessages {
            if let role = message["role"] as? String, let content = message["content"] as? String {
                let rolePrefix = role == "user" ? "用户：" : "助手："
                // 只取每条消息的前50个字符
                let truncatedContent = content.count > 50 ? String(content.prefix(50)) + "..." : content
                summary += rolePrefix + truncatedContent + "\n"
            }
        }
        
        return summary
    }
    
    // RAG检索功能：根据用户问题的关键词从知识库中检索相关信息
    private func retrieveRelevantKnowledge(for query: String) -> String {
        var relevantKnowledge = ""
        let keywords = extractKeywords(from: query)
        print("提取的关键词: \(keywords)")
        
        // 基于关键词进行检索
        for item in knowledgeBase {
            let itemLowercased = item.lowercased()
            for keyword in keywords {
                if itemLowercased.contains(keyword.lowercased()) {
                    relevantKnowledge += item + "\n"
                    break // 每个知识库条目只添加一次
                }
            }
        }
        
        return relevantKnowledge
    }
    
    // 处理语音输入
    func processVoiceInput(_ audioData: Data, onChunkReceived: @escaping (String) -> Void) async throws -> String {
        print("开始处理语音输入")
        
        // 这里需要实现语音识别功能
        // 由于是模拟，我们直接返回一个模拟的识别结果
        let recognizedText = "我想在无锡马拉松实现PB，怎么执行？"
        print("语音识别结果: \(recognizedText)")
        
        // 调用sendMessage方法处理识别后的文本
        return try await sendMessage(recognizedText, onChunkReceived: onChunkReceived)
    }
    
    // 读取附件内容
    private func readAttachmentContent(from url: URL) throws -> String {
        let fileExtension = url.pathExtension.lowercased()
        
        switch fileExtension {
        case "txt", "text":
            // 读取文本文件
            return try String(contentsOf: url, encoding: .utf8)
        case "doc", "docx":
            // 读取Word文档（模拟实现）
            return "Word文档内容：\n文件名为：\(url.lastPathComponent)\n\n[文档内容]"
        case "pdf":
            // 读取PDF文件（模拟实现）
            return "PDF文档内容：\n文件名为：\(url.lastPathComponent)\n\n[文档内容]"
        case "jpg", "jpeg", "png", "gif":
            // 读取图片文件，返回文件URL
            return "图片内容：\n文件名为：\(url.lastPathComponent)\nURL：\(url.absoluteString)\n\n[图片描述]"
        case "xlsx", "xls":
            // 读取Excel文件（模拟实现）
            return "Excel表格内容：\n文件名为：\(url.lastPathComponent)\n\n[表格内容]"
        default:
            // 其他文件类型（模拟实现）
            return "文件内容：\n文件名为：\(url.lastPathComponent)\n\n[文件内容]"
        }
    }
    
    // 优化表格显示
    private func optimizeTableDisplay(_ content: String) -> String {
        var optimizedContent = content
        
        // 移除Markdown标题标记和格式标记，但保留表情符号
        optimizedContent = optimizedContent.replacingOccurrences(of: #"^\s*#+.+\n"#, with: "", options: .regularExpression)
        optimizedContent = optimizedContent.replacingOccurrences(of: "###", with: "")
        optimizedContent = optimizedContent.replacingOccurrences(of: "***", with: "")
        optimizedContent = optimizedContent.replacingOccurrences(of: "**", with: "")
        optimizedContent = optimizedContent.replacingOccurrences(of: "#", with: "")
        
        // 移除表格中的分隔线
        optimizedContent = optimizedContent.replacingOccurrences(of: #"\|[-]+\|"#, with: "\n", options: .regularExpression)
        
        // 确保表格内容换行正确
        optimizedContent = optimizedContent.replacingOccurrences(of: "|\n", with: "\n")
        optimizedContent = optimizedContent.replacingOccurrences(of: "\n|", with: "\n")
        
        // 分段处理
        // 在关键点添加换行符
        let segmentationPoints = [
            "自动定位出发地：", "赛事起点地址：", "推荐交通方案", "推荐骑行方案",
            "路线：", "费用：", "耗时：", "步行总距离：",
            "注意事项", "方案1：", "方案2：", "预计计时",
            "总距离", "关键路线步骤", "步骤", "提示", "建议",
            "1.", "2.", "3.", "4.", "5.", "6.", "7.", "8.", "9.", "10."
        ]
        
        for point in segmentationPoints {
            optimizedContent = optimizedContent.replacingOccurrences(of: point, with: "\n" + point)
        }
        
        // 移除多余的空格和空行，但保留表情符号
        optimizedContent = optimizedContent.replacingOccurrences(of: #"[ \t]+"#, with: " ", options: .regularExpression)
        optimizedContent = optimizedContent.replacingOccurrences(of: #"\n+"#, with: "\n", options: .regularExpression)
        
        // 移除开头的空行
        optimizedContent = optimizedContent.replacingOccurrences(of: #"^\n+"#, with: "", options: .regularExpression)
        
        return optimizedContent
    }
    
    // 移除特定字符
    private func removeSpecialCharacters(_ content: String) -> String {
        // 移除#和*字符
        var result = content
        result = result.replacingOccurrences(of: "#", with: "")
        result = result.replacingOccurrences(of: "*", with: "")
        return result
    }
    
    // 对输出内容进行总结
    private func summarizeContent(_ content: String) -> String {
        // 简单的总结逻辑：保留开头和结尾部分，中间用省略号代替
        let maxLength = 2000 // 大约500个token
        if content.count <= maxLength {
            return content
        }
        
        let startLength = maxLength / 2
        let endLength = maxLength / 2
        
        let start = String(content.prefix(startLength))
        let end = String(content.suffix(endLength))
        
        return start + "..." + end
    }
    
    // 对输出内容进行RAG检索增强
    private func enhanceOutputWithRAG(_ output: String, for originalQuery: String) -> String {
        // 从输出内容中提取关键词
        let outputKeywords = extractKeywords(from: output)
        print("输出内容关键词: \(outputKeywords)")
        
        // 结合原始查询和输出关键词进行检索（但不添加到输出中）
        let combinedQuery = originalQuery + " " + output
        let relevantKnowledge = retrieveRelevantKnowledge(for: combinedQuery)
        print("检索到的相关知识: \(relevantKnowledge)")
        
        // 直接返回输入的output，避免重复处理
        return output
    }
    
    // 发送消息到Coze API（流式版本）// 发送消息到AI
    func sendMessage(_ message: String, attachments: [URL] = [], onChunkReceived: @escaping (String) -> Void) async throws -> String {
        print("开始发送消息到Coze API: \(message)")
        
        // 首先尝试v3 API端点
        let chatEndpoint = "https://api.coze.cn/v3/chat"
        print("使用聊天API端点: \(chatEndpoint)")
        
        guard let chatUrl = URL(string: chatEndpoint) else {
            throw NSError(domain: "AIService", code: 1001, userInfo: [NSLocalizedDescriptionKey: "无效的聊天API URL"])
        }
        
        var chatRequest = URLRequest(url: chatUrl)
        chatRequest.httpMethod = "POST"
        chatRequest.setValue("Bearer \(apiToken)", forHTTPHeaderField: "Authorization")
        chatRequest.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // 读取附件内容
        var attachmentContents: [String] = []
        for attachment in attachments {
            if let content = try? readAttachmentContent(from: attachment) {
                attachmentContents.append(content)
            }
        }
        
        // 合并消息和附件内容
        var combinedContent = message
        if !attachmentContents.isEmpty {
            for (index, content) in attachmentContents.enumerated() {
                combinedContent += "\n\n附件 \(index + 1)：\n\(content)"
            }
        }
        
        // 检索相关知识（基于合并后的内容）
        let relevantKnowledge = retrieveRelevantKnowledge(for: combinedContent)
        print("检索到的相关知识: \(relevantKnowledge)")
        
        // 提取关键词（基于合并后的内容）
        let keywords = extractKeywords(from: combinedContent)
        let keywordsString = keywords.isEmpty ? "" : "关键词：" + keywords.joined(separator: ", ")
        
        // 生成对话历史总结
        let conversationSummary = summarizeConversationHistory()
        
        // 构建增强后的消息
        var enhancedMessage = message
        if !keywordsString.isEmpty {
            enhancedMessage += "\n\n" + keywordsString
        }
        if !conversationSummary.isEmpty {
            enhancedMessage += "\n\n" + conversationSummary
        }
        if !attachmentContents.isEmpty {
            enhancedMessage += "\n\n附件内容："
            for (index, content) in attachmentContents.enumerated() {
                enhancedMessage += "\n\n附件 \(index + 1)：\n\(content)"
            }
        }
        if !attachments.isEmpty {
            enhancedMessage += "\n\n附件信息: "
            for attachment in attachments {
                enhancedMessage += "\n- \(attachment.lastPathComponent)"
            }
        }
        
        // 添加用户消息到当前对话
        let userMessage: [String: Any] = [
            "content": message,
            "content_type": "text",
            "role": "user",
            "type": "question"
        ]
        var currentMessages = self.currentConversationMessages
        currentMessages.append(userMessage)
        
        // 保持对话历史在合理范围内
        if currentMessages.count > self.maxHistoryLength {
            currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
        }
        
        // 更新当前对话消息
        self.currentConversationMessages = currentMessages
        
        // 如果是新对话的第一条消息，更新对话标题
        if currentMessages.count == 1 {
            let conversationId = conversations[currentConversationIndex].id
            let newTitle = message.prefix(20) + (message.count > 20 ? "..." : "")
            updateConversationTitle(conversationId: conversationId, title: String(newTitle))
        }
        
        // 构建请求体，只包含当前消息和增强信息，不发送完整对话历史
        let chatRequestBody: [String: Any] = [
            "bot_id": botId,
            "user_id": "123456789",
            "stream": true,
            "additional_messages": [
                [
                    "content": enhancedMessage,
                    "content_type": "text",
                    "role": "user",
                    "type": "question"
                ]
            ],
            "parameters": [
                "max_tokens": 500,  // 设置最大token为500
                "temperature": 0.7,
                "top_p": 0.9,        // Function tunning: 调整top_p参数
                "frequency_penalty": 0.1,  // Function tunning: 添加频率惩罚
                "presence_penalty": 0.1    // Function tunning: 添加存在惩罚
            ]
        ]
        
        do {
            chatRequest.httpBody = try JSONSerialization.data(withJSONObject: chatRequestBody, options: [])
            print("聊天请求体: \(chatRequestBody)")
        } catch {
            throw NSError(domain: "AIService", code: 1002, userInfo: [NSLocalizedDescriptionKey: "创建聊天请求体失败: \(error)"])
        }
        
        // 使用异步任务处理流式响应
        return try await withCheckedThrowingContinuation { continuation in
            let task = URLSession.shared.dataTask(with: chatRequest) { data, response, error in
                // 确保只调用一次onChunkReceived
                var responseSent = false
                
                func sendResponse(_ answer: String) {
                    if !responseSent {
                        responseSent = true
                        onChunkReceived(answer)
                        continuation.resume(returning: answer)
                    }
                }
                
                if let error = error {
                    print("聊天API调用失败: \(error)")
                    // API调用失败，返回模拟响应
                    let mockResponse = self.getMockResponse(for: message)
                    // 直接使用内容，不进行额外处理
                    var processedAnswer = mockResponse
                    // 只进行token限制处理
                    processedAnswer = self.summarizeContent(processedAnswer)
                    
                    // 添加模拟AI响应到当前对话
                    let aiMessage: [String: Any] = [
                        "content": processedAnswer,
                        "content_type": "text",
                        "role": "assistant",
                        "type": "answer"
                    ]
                    var currentMessages = self.currentConversationMessages
                    currentMessages.append(aiMessage)
                    
                    // 保持对话历史在合理范围内
                    if currentMessages.count > self.maxHistoryLength {
                        currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                    }
                    
                    // 更新当前对话消息
                    self.currentConversationMessages = currentMessages
                    
                    sendResponse(processedAnswer)
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse else {
                    print("无效的聊天响应")
                    let mockResponse = self.getMockResponse(for: message)
                    // 直接使用内容，不进行额外处理
                    var processedAnswer = mockResponse
                    // 只进行token限制处理
                    processedAnswer = self.summarizeContent(processedAnswer)
                    
                    // 添加模拟AI响应到当前对话
                    let aiMessage: [String: Any] = [
                        "content": processedAnswer,
                        "content_type": "text",
                        "role": "assistant",
                        "type": "answer"
                    ]
                    var currentMessages = self.currentConversationMessages
                    currentMessages.append(aiMessage)
                    
                    // 保持对话历史在合理范围内
                    if currentMessages.count > self.maxHistoryLength {
                        currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                    }
                    
                    // 更新当前对话消息
                    self.currentConversationMessages = currentMessages
                    
                    sendResponse(processedAnswer)
                    return
                }
                
                print("聊天状态码: \(httpResponse.statusCode)")
                
                guard let data = data else {
                    print("无响应内容")
                    let mockResponse = self.getMockResponse(for: message)
                    // 直接使用内容，不进行额外处理
                    var processedAnswer = mockResponse
                    // 只进行token限制处理
                    processedAnswer = self.summarizeContent(processedAnswer)
                    
                    // 添加模拟AI响应到当前对话
                    let aiMessage: [String: Any] = [
                        "content": processedAnswer,
                        "content_type": "text",
                        "role": "assistant",
                        "type": "answer"
                    ]
                    var currentMessages = self.currentConversationMessages
                    currentMessages.append(aiMessage)
                    
                    // 保持对话历史在合理范围内
                    if currentMessages.count > self.maxHistoryLength {
                        currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                    }
                    
                    // 更新当前对话消息
                    self.currentConversationMessages = currentMessages
                    
                    sendResponse(processedAnswer)
                    return
                }
                
                // 解析聊天响应，确保使用UTF-8编码
                let responseString = String(data: data, encoding: .utf8)
                print("聊天响应: \(responseString ?? "无响应内容")")
                
                // 处理响应
                if let responseString = responseString {
                    // 尝试解析SSE格式
                    let lines = responseString.components(separatedBy: "\n")
                    var fullAnswer = ""
                    
                    // 遍历所有行，只处理最后一个包含answer的data行
                    var lastAnswerContent: String?
                    for line in lines {
                        // 跳过空行
                        guard !line.isEmpty else { continue }
                        
                        // 检查是否是data行
                        if line.hasPrefix("data:") {
                            let dataPart = line.dropFirst(5).trimmingCharacters(in: .whitespaces)
                            // 跳过结束标记
                            if dataPart == "[DONE]" {
                                break
                            }
                            
                            do {
                                // 尝试解析JSON，确保使用UTF-8编码
                                if let jsonData = dataPart.data(using: .utf8),
                                   let eventData = try JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any] {
                                    
                                    // 检查是否是answer类型且有内容
                                    if let type = eventData["type"] as? String,
                                       type == "answer",
                                       let content = eventData["content"] as? String,
                                       !content.isEmpty {
                                        // 只保存最后一个answer内容
                                        lastAnswerContent = content
                                        print("获取答案: \(content)")
                                    }
                                }
                            } catch {
                                print("解析数据失败: \(error)")
                                // 继续处理下一行
                                continue
                            }
                        }
                    }
                    
                    // 使用最后一个answer内容
                    if let lastAnswerContent = lastAnswerContent {
                        fullAnswer = lastAnswerContent
                    }
                    
                    // 对完整的答案进行一次处理
                    if !fullAnswer.isEmpty {
                        // 先移除特殊字符
                        var processedAnswer = self.removeSpecialCharacters(fullAnswer)
                        // 再进行token限制处理
                        processedAnswer = self.summarizeContent(processedAnswer)
                        print("处理后的答案: \(processedAnswer)")
                        
                        // 添加AI响应到当前对话
                        let aiMessage: [String: Any] = [
                            "content": processedAnswer,
                            "content_type": "text",
                            "role": "assistant",
                            "type": "answer"
                        ]
                        var currentMessages = self.currentConversationMessages
                        currentMessages.append(aiMessage)
                        
                        // 保持对话历史在合理范围内
                        if currentMessages.count > self.maxHistoryLength {
                            currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                        }
                        
                        // 更新当前对话消息
                        self.currentConversationMessages = currentMessages
                        
                        // 只回调一次处理后的完整答案
                        sendResponse(processedAnswer)
                        return
                    }
                    
                    // 作为最后的尝试，检查是否是普通JSON响应
                    do {
                        if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                            print("尝试解析为普通JSON: \(json)")
                            
                            // 检查不同的响应格式
                            if let messages = json["messages"] as? [[String: Any]] {
                                for msg in messages {
                                    if let type = msg["type"] as? String, type == "answer", let content = msg["content"] as? String {
                                        // 先移除特殊字符
                                        var processedAnswer = self.removeSpecialCharacters(content)
                                        // 只进行token限制处理
                                        processedAnswer = self.summarizeContent(processedAnswer)
                                        print("从普通JSON找到答案: \(processedAnswer)")
                                        
                                        // 添加AI响应到当前对话
                                        let aiMessage: [String: Any] = [
                                            "content": processedAnswer,
                                            "content_type": "text",
                                            "role": "assistant",
                                            "type": "answer"
                                        ]
                                        var currentMessages = self.currentConversationMessages
                                        currentMessages.append(aiMessage)
                                        
                                        // 保持对话历史在合理范围内
                                        if currentMessages.count > self.maxHistoryLength {
                                            currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                                        }
                                        
                                        // 更新当前对话消息
                                        self.currentConversationMessages = currentMessages
                                        
                                        sendResponse(processedAnswer)
                                        return
                                    }
                                }
                            } else if let dataDict = json["data"] as? [String: Any], let messages = dataDict["messages"] as? [[String: Any]] {
                                for msg in messages {
                                    if let type = msg["type"] as? String, type == "answer", let content = msg["content"] as? String {
                                        // 先移除特殊字符
                                        var processedAnswer = self.removeSpecialCharacters(content)
                                        // 只进行token限制处理
                                        processedAnswer = self.summarizeContent(processedAnswer)
                                        print("从data字段找到答案: \(processedAnswer)")
                                        
                                        // 添加AI响应到当前对话
                                        let aiMessage: [String: Any] = [
                                            "content": processedAnswer,
                                            "content_type": "text",
                                            "role": "assistant",
                                            "type": "answer"
                                        ]
                                        var currentMessages = self.currentConversationMessages
                                        currentMessages.append(aiMessage)
                                        
                                        // 保持对话历史在合理范围内
                                        if currentMessages.count > self.maxHistoryLength {
                                            currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                                        }
                                        
                                        // 更新当前对话消息
                                        self.currentConversationMessages = currentMessages
                                        
                                        sendResponse(processedAnswer)
                                        return
                                    }
                                }
                            } else if let content = json["content"] as? String {
                                // 先移除特殊字符
                                var processedAnswer = self.removeSpecialCharacters(content)
                                // 只进行token限制处理
                                processedAnswer = self.summarizeContent(processedAnswer)
                                print("从content字段找到答案: \(processedAnswer)")
                                
                                // 添加AI响应到当前对话
                                let aiMessage: [String: Any] = [
                                    "content": processedAnswer,
                                    "content_type": "text",
                                    "role": "assistant",
                                    "type": "answer"
                                ]
                                var currentMessages = self.currentConversationMessages
                                currentMessages.append(aiMessage)
                                
                                // 保持对话历史在合理范围内
                                if currentMessages.count > self.maxHistoryLength {
                                    currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                                }
                                
                                // 更新当前对话消息
                                self.currentConversationMessages = currentMessages
                                
                                sendResponse(processedAnswer)
                                return
                            }
                        }
                    } catch {
                        print("解析普通JSON失败: \(error)")
                    }
                }
                
                // 如果所有尝试都失败，返回模拟响应
                print("API调用失败，使用模拟响应")
                var mockResponse = self.getMockResponse(for: message)
                
                // 先移除特殊字符
                var processedAnswer = self.removeSpecialCharacters(mockResponse)
                // 只进行token限制处理
                processedAnswer = self.summarizeContent(processedAnswer)
                
                // 添加模拟AI响应到当前对话
                let aiMessage: [String: Any] = [
                    "content": processedAnswer,
                    "content_type": "text",
                    "role": "assistant",
                    "type": "answer"
                ]
                var currentMessages = self.currentConversationMessages
                currentMessages.append(aiMessage)
                
                // 保持对话历史在合理范围内
                if currentMessages.count > self.maxHistoryLength {
                    currentMessages.removeFirst(currentMessages.count - self.maxHistoryLength)
                }
                
                // 更新当前对话消息
                self.currentConversationMessages = currentMessages
                
                sendResponse(processedAnswer)
            }
            
            task.resume()
        }
    }
    
    // 创建新对话
    func createNewConversation() -> String {
        let conversationId = UUID().uuidString
        let newConversation = Conversation(
            id: conversationId,
            title: "新对话",
            createdAt: Date(),
            messages: []
        )
        conversations.append(newConversation)
        currentConversationIndex = conversations.count - 1
        saveConversations()
        print("创建新对话: \(conversationId)")
        return conversationId
    }
    
    // 切换对话
    func switchConversation(to conversationId: String) -> Bool {
        if let index = conversations.firstIndex(where: { $0.id == conversationId }) {
            currentConversationIndex = index
            print("切换到对话: \(conversationId)")
            return true
        }
        return false
    }
    
    // 获取对话列表
    func getConversations() -> [Conversation] {
        return conversations
    }
    
    // 获取当前对话
    func getCurrentConversation() -> Conversation {
        return conversations[currentConversationIndex]
    }
    
    // 更新对话标题
    func updateConversationTitle(conversationId: String, title: String) {
        if let index = conversations.firstIndex(where: { $0.id == conversationId }) {
            var updatedConversation = conversations[index]
            updatedConversation.title = title
            conversations[index] = updatedConversation
            saveConversations()
        }
    }
    
    // 删除对话
    func deleteConversation(conversationId: String) {
        if let index = conversations.firstIndex(where: { $0.id == conversationId }) {
            conversations.remove(at: index)
            if currentConversationIndex >= conversations.count {
                currentConversationIndex = max(0, conversations.count - 1)
            }
            saveConversations()
        }
    }
    
    // 保存对话列表到文件
    private func saveConversations() {
        do {
            // 转换对话列表为可编码格式
            let encoder = JSONEncoder()
            encoder.dateEncodingStrategy = .iso8601
            let data = try encoder.encode(conversations)
            let url = getDocumentsDirectory().appendingPathComponent(conversationsFileName)
            try data.write(to: url)
            print("对话列表保存成功，共\(conversations.count)个对话")
        } catch {
            print("保存对话列表失败: \(error)")
        }
    }
    
    // 从文件加载对话列表
    private func loadConversations() {
        do {
            let url = getDocumentsDirectory().appendingPathComponent(conversationsFileName)
            if FileManager.default.fileExists(atPath: url.path) {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                let loadedConversations = try decoder.decode([Conversation].self, from: data)
                conversations = loadedConversations
                currentConversationIndex = max(0, conversations.count - 1)
                print("对话列表加载成功，共\(conversations.count)个对话")
            }
        } catch {
            print("加载对话列表失败: \(error)")
            // 如果加载失败，创建一个新的对话
            if conversations.isEmpty {
                _ = createNewConversation()
            }
        }
    }
    
    // 获取文档目录
    private func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    
    // 获取当前对话的消息
    private var currentConversationMessages: [[String: Any]] {
        get {
            return conversations[currentConversationIndex].messages
        }
        set {
            var updatedConversation = conversations[currentConversationIndex]
            updatedConversation.messages = newValue
            conversations[currentConversationIndex] = updatedConversation
            saveConversations()
        }
    }
    
    // 兼容旧版本的sendMessage方法
    func sendMessage(_ message: String, attachments: [URL] = []) async throws -> String {
        var result = ""
        try await sendMessage(message, attachments: attachments) { chunk in
            result += chunk
        }
        return result
    }
    
    // 模拟AI响应
    func getMockResponse(for message: String) -> String {
        if message.contains("PB") || message.contains("个人最好成绩") {
            return "要实现PB，你需要制定科学的训练计划，包括：\n1. 短期（1-4周）：每周增加10%的训练量，注重基础耐力\n2. 中期（1-3个月）：加入速度训练和间歇跑\n3. 长期（3个月以上）：模拟比赛配速，调整饮食和休息\n\n同时，注意比赛策略，根据气温、湿度等环境因素调整配速。"
        } else if message.contains("膝盖") || message.contains("受伤") {
            return "跑步膝盖疼的恢复建议：\n1. 短期（1-2周）：暂停跑步，改为低冲击运动，急性期冰敷，拉伸受伤肌群\n2. 长期（2周-3个月）：逐步恢复跑步，强化薄弱肌群，调整跑姿/装备\n\n如果疼痛持续超过2周或伴随肿胀/发热，建议及时就医。"
        } else if message.contains("训练计划") {
            return "制定训练计划需要考虑以下因素：\n1. 你的年龄、现阶段PB、目标成绩\n2. 跑步经验、每周训练天数及时长\n3. 有无运动偏好、有无旧伤\n\n一般建议：每周训练增幅不超过10%，结合有氧基础、速度训练和恢复训练。"
        } else {
            return "你好！我是你的AI跑步助手，有什么关于跑步的问题可以问我哦！"
        }
    }
}
