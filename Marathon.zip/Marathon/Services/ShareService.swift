import Foundation
import UIKit

class ShareService {
    static let shared = ShareService()
    
    // 分享到小红书
    func shareToXiaohongshu(medal: Medal) {
        // 生成小红书文案
        let prompt = AIService.shared.getXiaohongshuPrompt(title: medal.title, description: medal.description)
        
        // 模拟AI生成文案
        AIService.shared.processWithAI(prompt: prompt) { result in
            // 模拟分享
            print("分享到小红书：\(result)")
        }
    }
    
    // 分享到微信
    func shareToWechat(medal: Medal) {
        // 生成微信文案
        let content = "【马拉松奖牌】\n\(medal.title)\n\(medal.description)"
        
        // 模拟分享
        print("分享到微信：\(content)")
    }
    
    // 分享到抖音
    func shareToDouyin(medal: Medal) {
        // 生成抖音文案
        let content = "#马拉松 #奖牌收藏\n\(medal.title)\n\(medal.description)"
        
        // 模拟分享
        print("分享到抖音：\(content)")
    }
    
    // 分享到QQ
    func shareToQQ(medal: Medal) {
        // 生成QQ文案
        let content = "马拉松奖牌分享\n\(medal.title)\n\(medal.description)"
        
        // 模拟分享
        print("分享到QQ：\(content)")
    }
    
    // 通用分享方法
    func share(medal: Medal, platform: SharePlatform) {
        switch platform {
        case .xiaohongshu:
            shareToXiaohongshu(medal: medal)
        case .wechat:
            shareToWechat(medal: medal)
        case .moments:
            shareToWechat(medal: medal)
        case .douyin:
            shareToDouyin(medal: medal)
        case .qq:
            shareToQQ(medal: medal)
        }
    }
}

enum SharePlatform {
    case xiaohongshu
    case wechat
    case moments
    case qq
    case douyin
}
